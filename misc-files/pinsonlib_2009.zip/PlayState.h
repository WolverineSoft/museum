//Play gamestate class
#ifndef PLAYSTATE_H
#define PLAYSTATE_H

#include <zenilib.h>
using namespace Zeni;

class PlayState : public Zeni::Gamestate_Base
{
	public:
		PlayState();
		~PlayState();

	private:
		void on_key(const SDL_KeyboardEvent &event);
		void perform_logic();
		void render();

		bool m_paused;

};

#endif
