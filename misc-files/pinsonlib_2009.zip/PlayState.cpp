#include "PlayState.h"

#include <zenilib.h>

using namespace Zeni;

const SDLKey pause_key = SDLK_p;

PlayState::PlayState()
{
	m_paused = false;
}

PlayState::~PlayState()
{
}

void PlayState::on_key(const SDL_KeyboardEvent &event)
{

	if (m_paused)
	{
		if (event.keysym.sym == pause_key && event.type == SDL_KEYDOWN)
		{
			m_paused = false;
		}
	}
	else
	{
		Game &gr = get_Game();
		switch(event.keysym.sym)
		{
			case SDLK_ESCAPE:
				gr.pop_state();
				break;
			case pause_key:
				if (event.type == SDL_KEYDOWN)
				{
					m_paused = true;
				}
				break;
			default:
				break;
		}
	}
}

void PlayState::perform_logic()
{
}

void PlayState::render()
{
}
