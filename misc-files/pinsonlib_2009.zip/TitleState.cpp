#include "TitleState.h"

#include <zenilib.h>

using namespace Zeni;

TitleState::TitleState()
{
}

TitleState::~TitleState()
{
}

void TitleState::render()
{
	m_play_button.render();
	m_quit_button.render();
	/*render_image("logo",
                 Point2f(200.0f, 0.0f),
                 Point2f(600.0f, 200.0f));*/
}
