//Title gamestate class
#ifndef TITLESTATE_H
#define TITLESTATE_H

#include <zenilib.h>

#include "PlayState.h"

using namespace Zeni;

class TitleState : public Zeni::Gamestate_Base
{
	public:
		TitleState();
		~TitleState();
	  
	private:
		void on_key(const SDL_KeyboardEvent &event) {
			m_play_button.on_event(event);
			m_quit_button.on_event(event);
		  }

		  void on_mouse_motion(const SDL_MouseMotionEvent &event) {
			m_play_button.on_event(event);
			m_quit_button.on_event(event);
		  }

		  void on_mouse_button(const SDL_MouseButtonEvent &event) {
			m_play_button.on_event(event);
			m_quit_button.on_event(event);
		  }

		  void render();		
		
		
		  class Play_Button : public Text_Button {
		  public:
			Play_Button::Play_Button()
			  : Text_Button(Point2f(300.0f, 200.0f), Point2f(500.0f, 280.0f),
							Color(),
							"font",
							"Play",
							Color(1.0f, 0.0f, 0.0f, 0.0f))
			{
			}

			void on_accept() {
			  get_Game().push_state(new PlayState());
			}
		  } m_play_button;

		class Quit_Button : public Text_Button {
		  public:
			Quit_Button::Quit_Button()
			  : Text_Button(Point2f(300.0f, 320.0f), Point2f(500.0f, 400.0f),
							Color(),
							"font",
							"Quit",
							Color(1.0f, 0.0f, 0.0f, 0.0f))
			{
			}

			void on_accept() {
			  throw Quit_Event();
			}
		  } m_quit_button;
  
};

#endif
