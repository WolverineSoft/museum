#pragma once

#include "GameObject.h"

class SpriteObject : public GameObject
{
	std::string texture;
public:
	SpriteObject(Vector2 pos_, Vector2 scale_, std::string texture_);
	void setTexture(std::string texture_) { texture = texture_; }
	void render();
};

class WallObject : public SpriteObject
{
public:
	WallObject(Vector2 pos_, Vector2 scale_, std::string texture_);
};