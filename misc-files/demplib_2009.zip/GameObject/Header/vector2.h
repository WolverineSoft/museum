#pragma once

#include <math.h>
#include "zenilib.h"

const float pi = acos(-1.0f);

class Vector2
{
    public:
            Vector2();    
   			Vector2(const Vector2& v);
   			Vector2(float x_, float y_);
			Vector2& operator=(const Vector2& v);
			bool operator==(const Vector2& v) const;
			bool operator!=(const Vector2& v) const;
        	Vector2& operator+=(const Vector2& v);
        	Vector2& operator-=(const Vector2& v);
        	Vector2& operator*=(const float s);
			Vector2& operator/=(float s);

            float length2() { return x*x + y*y;}
            float length() { return sqrtf(length2());}
            Vector2 normal();
			void normalize();
			Vector2	perp() const;
			Vector2	reflectionOver(Vector2 & normal);
			Vector2	rotate(float theta);
			Vector2& transform(const Vector2 & trans, float rot);
			Vector2	rotateAround(Vector2 & pt, float theta);
			float angle();
			bool zero() { return abs(x) < 0.0001f && abs(y) < 0.0001f; }
			void swap(Vector2& other);
			Zeni::Point2f toPoint2f() { return Zeni::Point2f(x, y); }
 
            float x, y;      
};

Vector2	operator+(const Vector2& v1, const Vector2& v2); //sum of two vectors
Vector2	operator-(const Vector2& v1, const Vector2& v2); //difference of two vectors
float operator*(const Vector2& v1, const Vector2& v2); //dot product of two vectors
float operator^(const Vector2& v1, const Vector2& v2); //cross product of two vectors
Vector2	multiply(const Vector2& v1, const Vector2& v2); //multiple of two vectors
Vector2	operator*(const Vector2& v, const float s); //multiple of vector and scalar
Vector2	operator*(const float s, const Vector2& v); //multiple of scalar and vector
Vector2	operator/(const Vector2& v1, const Vector2& v2); //quotient of two vectors
Vector2	operator/(const Vector2& v, const float s); //quotient of vector and scalar
Vector2	operator-(const Vector2& v ); //negative vector