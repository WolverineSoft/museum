#pragma once

#include "vector2.h"

struct CollisionInfo
{
	CollisionInfo();

	// overlaps
	bool	m_overlapped;
	float	m_mtdLengthSquared;
	Vector2	m_mtd;

	// swept
	bool	m_collided; 
	Vector2	m_Nenter;
	Vector2	m_Nleave;
	float	m_tenter;
	float	m_tleave;
};

struct SupportPoints
{
	SupportPoints();
	
	enum { MAX_SUPPORTS = 4 };
	Vector2 m_support[MAX_SUPPORTS];
	int m_count;
};

struct ContactPair
{
	ContactPair();
	ContactPair(const Vector2& a, const Vector2& b);
	
	Vector2 m_position[2];
	float m_distanceSquared;
};

struct ContactInfo
{
	ContactInfo();

	ContactInfo(const SupportPoints& supports1, const SupportPoints& supports2);
	void edgeEdge(const Vector2* edge1 , const Vector2* edge2);
	void edgeVertex(const Vector2* edge, const Vector2& vertex);
	void vertexEdge(const Vector2& vertex, const Vector2* edge);
	void vertexVertex(const Vector2& vertex1, const Vector2& vertex2);

	enum { MAX_CONTACTS = 8 };
	ContactPair m_contact[MAX_CONTACTS];
	int m_count;
};