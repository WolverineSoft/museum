#pragma once

#include <vector>
#include "vector2.h"
#include "Collision.h"

// basic polygon structure
struct Poly
{
public:
	Poly();
	Poly(Vector2 & upperLeft, Vector2 & lowerRight); //rectangle
	Poly(Vector2 & center, float radius, float numpoints); //perfect polygon / circle

	void			transform	(const Vector2& position, float rotation);
	void			translate	(const Vector2& delta);
	CollisionInfo	collide		(const Poly& poly, const Vector2& delta) const;
	SupportPoints	getSupports	(const Vector2& axis);
	Poly& 			operator=	( const Poly& p );
	float calculateMass(float density);
	float calculateInertia();
	
public:
	std::vector<Vector2> m_vertices;
	int	size;
	Vector2& operator[](int i) { return m_vertices[i]; }
	void push_back(Vector2 vertex) { m_vertices.push_back(vertex); size++; }

	// collision functions
private:
	void calculateInterval(const Vector2& axis, float& min, float& max) const;
	bool separatedByAxis		(const Vector2& axis, const Poly& poly, const Vector2& delta, CollisionInfo& info) const;
	bool separatedByAxis_swept	(const Vector2& axis, float d0, float d1, float v, CollisionInfo& info) const;
	bool separatedByAxis_overlap(const Vector2& axis, float d0, float d1, CollisionInfo& info) const;
};

