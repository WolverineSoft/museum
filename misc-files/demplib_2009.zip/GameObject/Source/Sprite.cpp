#include "Sprite.h"

SpriteObject::SpriteObject(Vector2 pos_, Vector2 scale_, std::string texture_) :
	GameObject(pos_, scale_),
	texture(texture_)
{
	poly = Poly(pos - scale / 2, pos + scale / 2);
	mass = poly.calculateMass(0.5f); //0.5f is density on scale 0 to 1
	inertia = poly.calculateInertia();
}

void SpriteObject::render()
{
	render_image(texture,
				 (pos - scale / 2).toPoint2f(),
				 (pos + scale / 2).toPoint2f(),
				 rot,
				 1,
				 pos.toPoint2f());
}

WallObject::WallObject(Vector2 pos_, Vector2 scale_, std::string texture_) :
	SpriteObject(pos_, scale_, texture_)
{
	mass = 0.0f; //infinite
	inertia = 0.0f;
}