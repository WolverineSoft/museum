#include "Polygon.h"

using namespace std;

float Poly::calculateMass(float density)
{
	if (size < 2)
		return 5.0f * density;

	float mass = 0.0f;
	for(int j = size-1, i = 0; i < size; j = i, i ++)
		mass +=  (float) fabs(m_vertices[i] ^ m_vertices[j]);
	
	mass *= density * 0.5f;
	return mass;
}

float Poly::calculateInertia()
{
	if (size == 1) 
		return 0.0f;

	float denom = 0.0f;
	float numer = 0.0f;
	for(int j = size-1, i = 0; i < size; j = i, i ++)
	{
		float a = (float) fabs(m_vertices[i] ^ m_vertices[j]);
		float b = (m_vertices[j]*m_vertices[j] + m_vertices[j]*m_vertices[i] + m_vertices[i]*m_vertices[i]);
		denom += (a * b);
		numer += a;
	}
	float inertia = (denom / numer) * (1.0f / 6.0f);;
	return inertia;
}

Poly::Poly() : size(0)
{
}

Poly::Poly(Vector2 & upperLeft, Vector2 & lowerRight)
{
	size = 0;
	push_back(Vector2(upperLeft));
	push_back(Vector2(lowerRight.x, upperLeft.y));
	push_back(Vector2(lowerRight));
	push_back(Vector2(upperLeft.x, lowerRight.y)); 
}

Poly::Poly(Vector2 & center, float radius, float numpoints)
{
	size = 0;
	for(int i = 0; i < numpoints; i++){
		float a = 2.0f * pi * (i / (float)numpoints);
		push_back(center + Vector2(cos(a), sin(a)) * radius);
	}
}

Poly& Poly::operator=( const Poly& p )
{
	m_vertices.clear();
	size = 0;
	for (int i = 0; i < p.size; i++){
		push_back(p.m_vertices[i]);
	}
	return *this;
}

void Poly::transform(const Vector2& position, float rotation)
{
	for(int i = 0; i < size; i ++)
		m_vertices[i].transform(position, rotation);
}

void Poly::translate(const Vector2& delta)
{
	for(int i = 0; i < size; i ++)
		m_vertices[i] += delta;
}

CollisionInfo Poly::collide(const Poly& poly, const Vector2& delta) const
{
	CollisionInfo info;
	// reset info to some weird values
	info.m_overlapped = true;		 // we'll be regressing tests from there
	info.m_collided = true;
	info.m_mtdLengthSquared = -1.0f; // flags mtd as not being calculated yet
	info.m_tenter = 1.0f;			 // flags swept test as not being calculated yet
	info.m_tleave = 0.0f;			 // <--- ....

		
	// test separation axes of current polygon
	for(int j = size-1, i = 0; i < size; j = i, i ++)
	{
		Vector2 v0 = m_vertices[j];
		Vector2 v1 = m_vertices[i];

		Vector2 edge = v1 - v0; // edge
		Vector2 axis = edge.perp(); // sep axis is perpendicular ot the edge
		
		if(separatedByAxis(axis, poly, delta, info))
			return CollisionInfo();
	}

	// test separation axes of other polygon
	for(int j = poly.size-1, i = 0; i < poly.size; j = i, i ++)
	{
		Vector2 v0 = poly.m_vertices[j];
		Vector2 v1 = poly.m_vertices[i];

		Vector2 edge = v1 - v0; // edge
		Vector2 axis = edge.perp(); // sep axis is perpendicular ot the edge
		if(separatedByAxis(axis, poly, delta, info))
			return CollisionInfo();
	}

	// sanity checks
	info.m_overlapped &= (info.m_mtdLengthSquared >= 0.0f);
	info.m_collided   &= (info.m_tenter <= info.m_tleave);	

	// normalise normals
	info.m_Nenter.normalize();
	info.m_Nleave.normalize();

	return info;
}

void Poly::calculateInterval(const Vector2& axis, float& min, float& max) const
{
	min = max = m_vertices[0] * axis;

	for(int i = 1; i < size; i ++)
	{
		float d = m_vertices[i] * axis;
		if (d < min) 
			min = d; 
		else if (d > max) 
			max = d;
	}
}

bool Poly::separatedByAxis(const Vector2& axis, const Poly& poly, const Vector2& delta, CollisionInfo& info) const
{
	float mina, maxa;
	float minb, maxb;

	// calculate both polygon intervals along the axis we are testing
	calculateInterval(axis, mina, maxa);
	poly.calculateInterval(axis, minb, maxb);

	// calculate the two possible overlap ranges.
	// either we overlap on the left or right of the polygon.
	float d0 = (maxb - mina); // 'left' side
	float d1 = (minb - maxa); // 'right' side
	float v  = (axis * delta); // project delta on axis for swept tests

	bool sep_overlap = separatedByAxis_overlap(axis, d0, d1, info);
	bool sep_swept   = separatedByAxis_swept  (axis, d0, d1, v, info);
	
	// both tests didnt find any collision
	// return separated
	return (sep_overlap && sep_swept);
}

bool Poly::separatedByAxis_overlap(const Vector2& axis, float d0, float d1, CollisionInfo& info) const
{
	if(!info.m_overlapped)
		return true;

	// intervals do not overlap. 
	// so no overlpa possible.
	if(d0 < 0.0f || d1 > 0.0f)
	{
		info.m_overlapped = false;
		return true;
	}
	
	// find out if we overlap on the 'right' or 'left' of the polygon.
	float overlap = (d0 < -d1)? d0 : d1;

	// the axis length squared
	float axis_length_squared = axis * axis;

	// the mtd Vector2 for that axis
	Vector2 sep = axis * (overlap / axis_length_squared);

	// the mtd Vector2 length squared.
	float sep_length_squared = sep * sep;

	// if that Vector2 is smaller than our computed MTD (or the mtd hasn't been computed yet)
	// use that Vector2 as our current mtd.
	if(sep_length_squared < info.m_mtdLengthSquared || (info.m_mtdLengthSquared < 0.0f))
	{
		info.m_mtdLengthSquared = sep_length_squared;
		info.m_mtd				= sep;
	}
	return false;
}

bool Poly::separatedByAxis_swept(const Vector2& axis, float d0, float d1, float v, CollisionInfo& info) const
{
	if(!info.m_collided)
		return true;

	// projection too small. ignore test
	if(fabs(v) < 0.0000001f) return true;

	Vector2 N0 = axis;
	Vector2 N1 = -axis;
	float t0 = d0 / v;   // estimated time of collision to the 'left' side
	float t1 = d1 / v;  // estimated time of collision to the 'right' side

	// sort values on axis
	// so we have a valid swept interval
	if(t0 > t1) 
	{
		swap(t0, t1);
		N0.swap(N1);
	}
	
	// swept interval outside [0, 1] boundaries. 
	// polygons are too far apart
	if(t0 > 1.0f || t1 < 0.0f)
	{
		info.m_collided = false;
		return true;
	}

	// the swept interval of the collison result hasn't been
	// performed yet.
	if(info.m_tenter > info.m_tleave)
	{
		info.m_tenter = t0;
		info.m_tleave = t1;
		info.m_Nenter = N0;
		info.m_Nleave = N1;
		// not separated
		return false;
	}
	// else, make sure our current interval is in 
	// range [info.m_tenter, info.m_tleave];
	else
	{
		// separated.
		if(t0 > info.m_tleave || t1 < info.m_tenter)
		{
			info.m_collided = false;
			return true;
		}

		// reduce the collison interval
		// to minima
		if (t0 > info.m_tenter)
		{
			info.m_tenter = t0;
			info.m_Nenter = N0;
		}
		if (t1 < info.m_tleave)
		{
			info.m_tleave = t1;
			info.m_Nleave = N1;
		}			
		// not separated
		return false;
	}
}

SupportPoints Poly::getSupports(const Vector2& axis)
{
	SupportPoints supports;

	float min = -1.0f;
	const float threshold = 1.0E-1f;
	int count = 0;

	int num = size;
	for(int i = 0; i < num; i ++)
	{
		float t = axis * m_vertices[i];
		if(t < min || i == 0)
			min = t;
	}

	for(int i = 0; i < num; i ++)
	{
		float t = axis * m_vertices[i];
		
		if(t < min+threshold)
		{
			supports.m_support[supports.m_count++] = m_vertices[i];
			if (supports.m_count == 2) break;
		}
	}
	return supports;
}