Release Notes - DXFramework 0.9.4

DXFramework is a simple, illustrative, general purpose 2D computer game engine 
for Microsoft Visual Studio using Microsoft's DirectX technology.

Be advised: DXFramework 0.9.4 is a MAJOR upgrade. The entire engine has been 
rewritten and is not compatible with previous versions. Version 0.9.4 continues 
DXFramework's well-known design paradigm while employing Microsoft's DXUT 
libraries offering much more power, compatibility and opportunities than in the 
past. Users familiar with DXUT will find that they are able to use its advanced 
features in parallel with the new DXFramework.

Although 3D support as it exists in previous versions of DXFramework has not yet 
been ported to the new engine, the engine is 3D-ready in that DXUT 3D 
functionality may be directly employed. 

Please see the getting started guide on the DXFramework wiki along with the 
other documentation hosted there if you are interested in using DXFramework for 
a project:
 * http://winter.eecs.umich.edu/dxf-wiki

The dxframework-0.9.4.zip package contains:
 * Engine library source & project files for Microsoft Visual Studio .NET 2003
 * Demos and media demonstrating simple use of the engine  
 * Templates to  simplify creation of new projects created with Visual Studio

Please see the DXFramework home page for more information about DXFramework:
 * http://dxframework.sourceforge.net/

Latest DXFramework news is available here:
 * http://sourceforge.net/projects/dxframework/

Notice for people using MSVC 6 and MSVC .NET 2002:
We no longer support MSVC 6 and MSVC .NET 2002.

Design Notes:
 * This is a beta release.  Most features are working, but some are still 
   on the way or are only partially complete.  Many features have been added
   but are not tested.

Please put all questions and concerns on the SourceForge forum:
 * http://sourceforge.net/forum/?group_id=54927
