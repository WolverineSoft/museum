/*	DXFramework Copyright (c) 2005, Jonathan Voigt, University of Michigan.
	See http://dxframework.sourceforge.net/ for a list of contributors.
	All rights reserved.

	Redistribution and use in source and binary forms, with or without modification, 
	are permitted provided that the following conditions are met:

		* Redistributions of source code must retain the above copyright notice, 
		this list of conditions and the following disclaimer.

		* Redistributions in binary form must reproduce the above copyright notice, 
		this list of conditions and the following disclaimer in the documentation 
		and/or other materials provided with the distribution.

		* Neither the name of the DXFramework project nor the names of its 
		contributors may be used to endorse or promote products derived from this 
		software without specific prior written permission.

	THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND 
	ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED 
	WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE 
	DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR 
	ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES 
	(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; 
	LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON 
	ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT 
	(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS 
	SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/

#pragma once

#include "dxframework.h"
#include "dxf_texture.h"

namespace dxf {
	/** Sprites are pretty much everything on the screen in 2D games and applications.
	*/
	class Sprite {
	public:

		Sprite();

		/** Load the sprite from a file using the passed color as the color to use as transparent.
			If the sprite format has an alpha channel, the transparent color is ignored.

			@param name Name of the sprite. If the name is of the format name-x-y-z.ext where x
			y and z are all numbers, this will automatically set the animation parameters to 
			x = count, y = cols, z = rows.  See SetAnimationParameters below.
		*/
		HRESULT CreateFromFile(const std::wstring& filename, D3DCOLOR transparent = 0);

		/** Create the new sprite from an existing, client-owned texture.
		*/
		HRESULT CreateFromTexture(const Texture& texture);

		void Unload();

		/** Draw the sprite on the screen using the stored position coordinates.
		*/
		void Render2D();
		/** Draw the sprite on the screen using the passed temporary coordinates.
		*/
		void Render2D(const D3DXVECTOR2& position);

		/** Get the width and height of the sprite as it appears on the screen.  If the sprite
			is an animation, this will be a frame height and width.
		*/
		unsigned GetWidth() const;
		/** Get the width and height of the sprite as it appears on the screen.  If the sprite
			is an animation, this will be a frame height and width.
		*/
		unsigned GetHeight() const;
		/** Get the unscaled center of the sprite.  This will be the center of a frame in
			an animated sprite.
		*/
		D3DXVECTOR2	GetAbsoluteCenter() const;
		/** Get the current scaling factor.
		*/
		D3DXVECTOR2 GetScaling() const;
        /** Get the current color. (added by AP)
		*/
		D3DXCOLOR GetColor() const;

		/**	Set the x,y position of the sprite on the screen.  This is the position of the upper-
			left pixel of the sprite.
		*/
		void SetPosition(int x, int y);
		/** Set the x,y position of the sprite on the screen.  This is the position of the upper-
			left pixel of the sprite.
		*/
		void SetPosition(const D3DXVECTOR2& position);
		/** Set the scaling of the sprite.  This is 1, 1 for non-scaled sprites.
		*/
		void SetScaling(float x, float y);
		/** Set the scaling of the sprite.  This is 1, 1 for non-scaled sprites.
		*/
		void SetScaling(const D3DXVECTOR2& scaling);
		/** Set the center of rotation for the sprite, use height/2, width/2 to rotate around
			the center.
		*/
		void SetRotationCenter(const D3DXVECTOR2& rotationCenter);
		/** Set rotation in radians, positive is counterclockwise. 
		*/
		void SetRotation(const float& rotation);
		/** Set color, a white sprite will change to this color, other colors will 
			have interesting results. (altered by AP)
		*/
		void SetColor(D3DCOLOR color);

		/** Check to see if the point p is inside of the sprite
		*/
		bool CheckIntersection(const POINT& p);

		Texture* GetTexture();
		IDirect3DTexture9* GetD3DTexture();

		/** Override the animation parameters in the filename.
			@param count number of animation frames in the image, can't be more than rows * cols
			@param cols number of columns in the image, sprite width is texture width / this number
			@param rows number of rows in the image, sprite height is texture height / this number
		*/
		HRESULT SetAnimationParameters(int count, int cols, int rows);
		/** Set the current animation frame to the specified frame
		*/
		void SetAnimation(int frame);
		/** Set the current animation frame to be the next frame, from left to right then down a row.
		*/
		void Animate();
	private:

		HRESULT Init();
		void UpdateRect();

		Texture texture;		
		bool destroyTexture;	
		int rows;			
		int cols;			
		RECT rect;			
		int frame;		
		int count;

		D3DXVECTOR2 position;
		D3DXVECTOR2 scaling;
		D3DXVECTOR2 rotationCenter;
		float rotation;
		D3DXCOLOR color;	//changed to D3DXCOLOR from D3DCOLOR by AP
	};
} // namespace dxf
