#include "dxf_music.h"

namespace dxf {
	HRESULT Music::Load(const std::wstring& filename) {
		HRESULT hr;

		playing = false;

		V_RETURN(CoCreateInstance(CLSID_FilterGraph, NULL, CLSCTX_INPROC_SERVER, IID_IGraphBuilder, (void**)&pGraphBuilder));
		V_RETURN(pGraphBuilder->QueryInterface(IID_IMediaControl, (void**)&pMediaControl));
		V_RETURN(pGraphBuilder->QueryInterface(IID_IMediaEvent, (void**)&pMediaEvent));
		V_RETURN(pGraphBuilder->QueryInterface(IID_IMediaPosition, (void**)&pMediaPosition));
		V_RETURN(pGraphBuilder->QueryInterface(IID_IBasicAudio, (void**)&pBasicAudio));
		V_RETURN(pMediaEvent->SetNotifyWindow((OAHWND)DXUTGetHWND(), WM_USER, 0));
		V_RETURN(pMediaEvent->SetNotifyFlags(0));	// turn on notifications

		// render the file
		std::wstring pathname(L"../media/");
		pathname += filename;
		V_RETURN(pGraphBuilder->RenderFile(pathname.c_str(), NULL));
		return S_OK;
	}

	void Music::Unload() {
		SAFE_RELEASE(pBasicAudio);
		SAFE_RELEASE(pMediaPosition);
		SAFE_RELEASE(pMediaEvent);
		SAFE_RELEASE(pMediaControl);
		SAFE_RELEASE(pGraphBuilder);
	}

	void Music::Play() {
		HRESULT hr;
		if (IsPlaying()) Stop();

		V(pMediaControl->Run());
		playing = true;
	}

	bool Music::IsPlaying() {
		HRESULT hr;
		long EventCode, p1, p2;
		V(pMediaEvent->GetEvent(&EventCode, &p1, &p2, 0) != E_ABORT);
		switch (EventCode) {
			case EC_COMPLETE:   
				Stop();
				break;
			default:
				break;
		}	
		V(pMediaEvent->FreeEventParams(EventCode, p1, p2));

		return playing;
	}

	void Music::Pause() {
		HRESULT hr;
		V(pMediaControl->Pause());
		playing = false;
	}

	void Music::Stop() {
		HRESULT hr;
		V(pMediaControl->Pause());
		V(pMediaControl->Stop());
		V(pMediaPosition->put_CurrentPosition(0));   // reset to beginning
		playing = false;
	}

	/** Will return pdRate (the speed at which the song is 
		played) (added by AP)
	*/
	HRESULT Music::GetRate(double* pdRate)
	{
		return pMediaPosition->get_Rate(pdRate);
	}

	/** Set the speed at which the song is played (added by AP)
	*/
	void Music::SetRate(double new_rate)
	{
		pMediaPosition->put_Rate(new_rate);
	}

	/** Will return plVolume (the current volume) (added by AP)
	*/
	HRESULT Music::GetVolume(long* plVolume)
	{
		return pBasicAudio->get_Volume(plVolume);
	}

	/** Set the volume (added by AP)
	*/
	void Music::SetVolume(long new_volume)
	{
		pBasicAudio->put_Volume(new_volume);
	}

	/** Will return plBalance (the current balance) (added by AP)
	*/
	HRESULT Music::GetBalance(long* plBalance)
	{
		return pBasicAudio->get_Balance(plBalance);
	}

	/** Set the balance (added by AP)
	*/
	void Music::SetBalance(long new_balance)
	{
		pBasicAudio->put_Balance(new_balance);
	}
} // namespace dxf