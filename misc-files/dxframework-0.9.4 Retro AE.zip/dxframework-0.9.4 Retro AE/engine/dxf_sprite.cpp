/*	DXFramework Copyright (c) 2005, Jonathan Voigt, University of Michigan.
	See http://dxframework.sourceforge.net/ for a list of contributors.
	All rights reserved.

	Redistribution and use in source and binary forms, with or without modification, 
	are permitted provided that the following conditions are met:

		* Redistributions of source code must retain the above copyright notice, 
		this list of conditions and the following disclaimer.

		* Redistributions in binary form must reproduce the above copyright notice, 
		this list of conditions and the following disclaimer in the documentation 
		and/or other materials provided with the distribution.

		* Neither the name of the DXFramework project nor the names of its 
		contributors may be used to endorse or promote products derived from this 
		software without specific prior written permission.

	THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND 
	ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED 
	WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE 
	DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR 
	ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES 
	(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; 
	LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON 
	ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT 
	(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS 
	SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/

#include "dxf_sprite.h"
#include "dxf_tools.h"
#include "dxf_texture.h"
#include "dxf_game.h"

namespace dxf {
	Sprite::Sprite() {
		position = D3DXVECTOR2(0,0);
		scaling = D3DXVECTOR2(1,1);
		rotationCenter = D3DXVECTOR2(0,0);
		rotation = 0;
		color = D3DCOLOR_ARGB(255,255,255,255);
	}

	HRESULT Sprite::CreateFromFile(const std::wstring& filename, D3DCOLOR transparent) {
		HRESULT hr;
		V_RETURN(texture.CreateFromFile(filename, false, transparent));
		destroyTexture = true;

		return Init();
	}

	HRESULT Sprite::CreateFromTexture(const Texture& texture) {
		this->texture = texture;
		destroyTexture = false;

		return Init();
	}

	void Sprite::Unload() {
		if (destroyTexture) texture.Unload();
	}

	HRESULT Sprite::Init() {
		// find the position of each of the three variables
		int countPos	= texture.GetFilename().find(L"-") + 1;
		int colsPos		= texture.GetFilename().find(L"-", countPos) + 1;
		int rowsPos		= texture.GetFilename().find(L"-", colsPos) + 1;

		// did we find the three variables?
		if ((countPos > 0) && (colsPos > 0) && (rowsPos > 0)) {
			// convert the strings into integers
			return SetAnimationParameters(toint(texture.GetFilename().substr(countPos, colsPos - 1)), 
				toint(texture.GetFilename().substr(colsPos, rowsPos - 1)), toint(texture.GetFilename().substr(rowsPos, texture.GetFilename().find(L"."))));
		}
		
		return SetAnimationParameters(1, 1, 1);
	}

	HRESULT Sprite::SetAnimationParameters(int count, int cols, int rows) {
		// check for bad numbers
		if (count <= 0 || cols <= 0 || rows <= 0) {
			// numbers bad, use defaults
			count = 1;
			cols = 1;
			rows = 1;
		}

		// can't have more animations than cells in the image!
		if ((rows * cols) < count) return E_INVALIDARG;        

		// all is well, make permanant
		this->cols = cols;
		this->rows = rows;
		this->count = count;

		// set frame to 0 (array-like notation) and square it off
		// non-animated sprites essentially always in animation frame 0
		frame = 0;
		UpdateRect();
		return S_OK;
	}

	void Sprite::SetAnimation(int frame) {
		this->frame = frame;
		frame %= count;
		UpdateRect();				// update the bounding rectangle
	}

	void Sprite::Animate() {
		++frame;
		frame %= count;
		UpdateRect();											// update the bounding rectangle
	}

	void Sprite::UpdateRect() {    
		rect.top = (frame / cols) * GetHeight();
		rect.left = (frame % cols) * GetWidth();

		rect.bottom = rect.top + GetHeight();
		rect.right = rect.left + GetWidth();
	}

	void Sprite::Render2D() {
		D3DXMATRIX TransformMatrix;
		D3DXMatrixTransformation2D(&TransformMatrix, 0, 0, &scaling, &rotationCenter, -rotation, &position);

		// Apply transform matrix. This handles scaling, rotation, translation etc.
		HRESULT hr;
		V(DXFGetD3DXSprite()->SetTransform(&TransformMatrix));

		D3DXVECTOR3 zero = D3DXVECTOR3(0,0,0);
		V(DXFGetD3DXSprite()->Draw(texture.GetD3DTexture(), &rect, &zero, &zero, color));
	}

	void Sprite::Render2D(const D3DXVECTOR2& position) {

		D3DXMATRIX TransformMatrix;
		D3DXMatrixTransformation2D(&TransformMatrix, 0, 0, &scaling, &rotationCenter, -rotation, &position);

		// Apply transform matrix. This handles scaling, rotation, translation etc.
		HRESULT hr;
		V(DXFGetD3DXSprite()->SetTransform(&TransformMatrix));

		D3DXVECTOR3 zero = D3DXVECTOR3(0,0,0);
		V(DXFGetD3DXSprite()->Draw(texture.GetD3DTexture(), &rect, &zero, &zero, color));
	}

	unsigned Sprite::GetWidth() const { 
		return texture.GetWidth() / cols; 
	}
	unsigned Sprite::GetHeight() const { 
		return texture.GetHeight() / rows; 
	}
	D3DXVECTOR2 Sprite::GetAbsoluteCenter() const { 
		return D3DXVECTOR2(GetWidth() / 2.0f, GetHeight() / 2.0f);
	}
	D3DXCOLOR Sprite::GetColor() const
	{
		return color;
	}
	D3DXVECTOR2 Sprite::GetScaling() const {
		return scaling;
	}

	IDirect3DTexture9* Sprite::GetD3DTexture() { 
		return texture.GetD3DTexture(); 
	}	

	Texture* Sprite::GetTexture () { 
		return &texture; 
	}	

	void Sprite::SetPosition(int x, int y) {
		this->position = D3DXVECTOR2(static_cast<float>(x), static_cast<float>(y));
	}

	void Sprite::SetPosition(const D3DXVECTOR2& position) {
		this->position = position;
	}

	void Sprite::SetScaling(float x, float y) {
		this->scaling = D3DXVECTOR2(x,y);
	}

	void Sprite::SetScaling(const D3DXVECTOR2& scaling) {
		this->scaling = scaling;
	}

	void Sprite::SetRotationCenter(const D3DXVECTOR2& rotationCenter) {
		this->rotationCenter = rotationCenter;
	}

	void Sprite::SetRotation(const float& rotation) {
		this->rotation = rotation;
	}

	void Sprite::SetColor(D3DCOLOR color) {
		this->color = D3DXCOLOR(color);
	}

	bool Sprite::CheckIntersection(const POINT& p) {
		D3DRECT extent;
		extent.x1 = static_cast<LONG>(position.x);
		extent.x2 = extent.x1 + static_cast<LONG>(GetWidth() * scaling.x);
		extent.y1 = static_cast<LONG>(position.y);
		extent.y2 = extent.y1 + static_cast<LONG>(GetHeight() * scaling.y);
		
		return checkIntersection(p, extent);
	}
} // namespace dxf