/*	DXFramework Copyright (c) 2005, Jonathan Voigt, University of Michigan.
	See http://dxframework.sourceforge.net/ for a list of contributors.
	All rights reserved.

	Redistribution and use in source and binary forms, with or without modification, 
	are permitted provided that the following conditions are met:

		* Redistributions of source code must retain the above copyright notice, 
		this list of conditions and the following disclaimer.

		* Redistributions in binary form must reproduce the above copyright notice, 
		this list of conditions and the following disclaimer in the documentation 
		and/or other materials provided with the distribution.

		* Neither the name of the DXFramework project nor the names of its 
		contributors may be used to endorse or promote products derived from this 
		software without specific prior written permission.

	THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND 
	ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED 
	WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE 
	DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR 
	ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES 
	(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; 
	LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON 
	ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT 
	(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS 
	SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/

#pragma once

#include "dxframework.h"

namespace dxf {

	/** A DXFramework DXUT GUI wrapper class for use with GameState objects.

		Multiply inherit this with a GameState if you want to use the DXUT GUI in your game states
	*/
	class GUI {
	public:
		/** Called when the device is invalidated, the back buffer may be a different size.  Reset
			screen locations and what not of GUI objects if applicable.
		*/
		virtual HRESULT OnResetDevice( IDirect3DDevice9* pd3dDevice, const D3DSURFACE_DESC* pBackBufferSurfaceDesc) = 0;

		/** Called right after the Render2D phase, draw the GUI objects on the screen.  Simply use
			to call OnRender on the dialog object.
		*/
		virtual HRESULT OnFrameRender(float fElapsedTime) = 0;

		/** Called when something happens to a GUI object. Varies with the object.  The affected
			object is identified by the nControlID parameter and is pointed to by pControl which
			probably needs to be casted into something other than CDXUTControl to be useful in
			this function.  See the GUI demo for an example on what to do here.
		*/
		virtual void OnGUIEvent( UINT nEvent, int nControlID, CDXUTControl* pControl, void* pUserContext ) = 0;

		/** Called when the device is created, passes the call to the Dialog Resource Manager.
		*/
		HRESULT OnCreateDevice( IDirect3DDevice9* pd3dDevice, const D3DSURFACE_DESC* pBackBufferSurfaceDesc);

		/** Called when the device is lost, passes the call to the Dialog Resource Manager.
		*/
		void OnLostDevice();

		/** Called when the device is destroyed, passes the call to the Dialog Resource Manager.
		*/
		void OnDestroyDevice();

		/** The top level container/manager for the CDXUTDialog stuff.
		*/
		static CDXUTDialogResourceManager drm;
	};
} // namespace dxf
		
