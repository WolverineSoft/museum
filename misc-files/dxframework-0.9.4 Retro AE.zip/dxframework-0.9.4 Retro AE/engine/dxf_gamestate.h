/*	DXFramework Copyright (c) 2005, Jonathan Voigt, University of Michigan.
	See http://dxframework.sourceforge.net/ for a list of contributors.
	All rights reserved.

	Redistribution and use in source and binary forms, with or without modification, 
	are permitted provided that the following conditions are met:

		* Redistributions of source code must retain the above copyright notice, 
		this list of conditions and the following disclaimer.

		* Redistributions in binary form must reproduce the above copyright notice, 
		this list of conditions and the following disclaimer in the documentation 
		and/or other materials provided with the distribution.

		* Neither the name of the DXFramework project nor the names of its 
		contributors may be used to endorse or promote products derived from this 
		software without specific prior written permission.

	THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND 
	ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED 
	WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE 
	DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR 
	ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES 
	(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; 
	LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON 
	ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT 
	(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS 
	SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/

#pragma once

namespace dxf {
	class GUI;

	/** A state node in the DXFramework state machine.  A DXFramework state contains
		all of the data and logic relevant to whatever is going on at the time.  Data
		and logic that persists throughout many states should either be in global 
		structures or in parent state managers.
	*/
	class GameState {
	public:
		/** Load is called after a change to this state is made, right after the previous state's
			Unload() function is called.  Return S_OK on success.
		*/
		virtual HRESULT Load() = 0;

		/** Unload is called when the state is changed from this state. Remove any claims on memory.
		*/
		virtual void Unload() = 0;

		/** Update is called during the update phase.  Use this time to update your world model,
			to read input, to perform as much logic as possible before the rendering phase.
		*/
		virtual void Update(double fTime, float fElapsedTime) = 0;

		/** Used to render 2D stuff like a static background behind a 3D scene.  Not used with
			2D applications.
		*/
		virtual void RenderPre2D(double fTime, float fElapsedTime) = 0;

		/** Used to render the 3D scene.  Not used with 2D applications.
		*/
		virtual void Render3D(double fTime, float fElapsedTime) = 0;

		/** The only render function used with 2D applications, used to render on top of any 3D
			scene that is going on in the background.  This is the place to put your GUI in a 
			3D application.
		*/
		virtual void Render2D(double fTime, float fElapsedTime) = 0;

		/** Called when the user or the operating system issues a resize or change of the back 
			buffer. Any assumptions made about the back buffer (anything in D3DSURFACE_DESC)
			are invalid at this point, so make new assumptions.
		*/
		virtual void Resize(const D3DSURFACE_DESC* pBackBufferSurfaceDesc) = 0;

		/** A client side intercept for the windows message pump.  Use to take messages
			away from the engine, such as the engine's desire to use escape to exit the
			application, quitting to OS.

			Return true if you handled the message, essentially telling the engine that you
			want it to ignore the message, that you dealt with it.

			Return false (the default behavior) if you did not handle the message and you
			want the engine to do what it pleases with the message.

			If you do nothing but return true here, you'll likely get a "Not Responding"
			tag in the task manager.  Bad.
		*/
		virtual bool MsgProc( HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam) = 0;

		GUI* GetGUI() { return pGUI; }
	protected:   
		GameState() { pGUI = 0; };
		GUI* pGUI;
	};
} // namespace dxf