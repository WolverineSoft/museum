/*	DXFramework Copyright (c) 2005, Jonathan Voigt, University of Michigan.
	See http://dxframework.sourceforge.net/ for a list of contributors.
	All rights reserved.

	Redistribution and use in source and binary forms, with or without modification, 
	are permitted provided that the following conditions are met:

		* Redistributions of source code must retain the above copyright notice, 
		this list of conditions and the following disclaimer.

		* Redistributions in binary form must reproduce the above copyright notice, 
		this list of conditions and the following disclaimer in the documentation 
		and/or other materials provided with the distribution.

		* Neither the name of the DXFramework project nor the names of its 
		contributors may be used to endorse or promote products derived from this 
		software without specific prior written permission.

	THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND 
	ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED 
	WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE 
	DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR 
	ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES 
	(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; 
	LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON 
	ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT 
	(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS 
	SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/

# pragma once

#include "dxframework.h"

namespace dxf {
	/** Much like the font info structure in the font class, this holds information about 
		the textures used in DXFramework.
	*/
	struct TextureInfo {
		IDirect3DTexture9*  pTexture;	///< the texture
		bool multipleLevel;				///< does it have mutiple resolution levels?
		D3DCOLOR transparent;			///< what's the default transparent color
		unsigned count;					///< number if references
		D3DXIMAGE_INFO imageInfo;		///< information about the texture
		std::wstring filename;			///< the file that this texture points to
		bool saved;						///< true if the texture is saved in its current format
	};

	typedef std::map<std::wstring, TextureInfo*> TextureInfoMap;
	typedef std::map<std::wstring, TextureInfo*>::iterator TextureInfoMapIter;

	/** Texture class, holds an image, put texture into a sprite class to draw it on the
		screen in 2D applications.
	*/
	class Texture {
	public:
		Texture();

		/**	Create the texture from a file
			@param filename the name of the file
			@param multipleLevel
			@param transparent the transparent color to use for this texture, if any
		*/
		HRESULT CreateFromFile(const std::wstring& filename, bool multipleLevel = false, D3DCOLOR transparent = 0);
		/**	Create a blank texture of the passed width and height */
		HRESULT CreateNew(const std::wstring& filename, unsigned width, unsigned height);

		void Unload();

		unsigned			GetWidth() const;	
		unsigned			GetHeight() const;
		std::wstring		GetFilename();
		IDirect3DTexture9*	GetD3DTexture();
		
		/** Must call this before doing any drawing */
		HRESULT				BeginDrawing();
		/** Must call this after doing any drawing */
		HRESULT				EndDrawing();

		/** Split color into components */
		void				ObtainARGBFromColor(DWORD color, unsigned char *p_A, char *p_R, unsigned char *p_G, unsigned char *p_B);

		/** Draw a pixel at x and y */
		void				PutPixel(unsigned x, unsigned y, DWORD color);
		/** See what the pixel at x and y is */
		DWORD				GetPixel(unsigned x, unsigned y);

		/** Draw a bar from point 1 to point 2 
			I'm not sure but I think the limitation here is a horizontal line, which
			begs the question of having two y points...
		*/
		void				Bar(unsigned x1, unsigned y1, unsigned x2, unsigned y2, DWORD color);
		/** Draw a rectangle with opposite corner points 1 and 2 */
		void				Rectangle(unsigned x1, unsigned y1, unsigned x2, unsigned y2, DWORD color);

		/** Draw a line from point 1 to point 2 */
		void				Line(unsigned x1, unsigned y1, unsigned x2, unsigned y2, DWORD color);

		/** Draw a circle */
		void				Circle(unsigned x, unsigned y, int radius, DWORD color);
		/** Draw an ellipse */
		void				Ellipse(unsigned x, unsigned y, int radiusX, int radiusY, DWORD color);

		/** Flood fill the area */
		void				FloodFill(unsigned x, unsigned y, DWORD color);

		/** Save the texture designated by the texture info to a file */
		static HRESULT SaveToFile(TextureInfo* pInfo);
		static HRESULT OnCreateDevice();
		static void OnDestroyDevice();
	private:
		static bool CheckInfoMap(const std::wstring& filename, bool multipleLevel, D3DCOLOR transparent);
		static TextureInfoMap infoMap;	///< keeps maps of texture info to filenames for memory management

		TextureInfo*		pInfo;					///< the texture info
		D3DLOCKED_RECT		lockedRect;				///< for locking texture/getting texture information
		unsigned char*		pPixels;				///< cached pointer to the pixels
		DWORD				pitch;					///< cached pitch
	};
} // namespace dxf