/*	DXFramework Copyright (c) 2005, Jonathan Voigt, University of Michigan.
	See http://dxframework.sourceforge.net/ for a list of contributors.
	All rights reserved.

	Redistribution and use in source and binary forms, with or without modification, 
	are permitted provided that the following conditions are met:

		* Redistributions of source code must retain the above copyright notice, 
		this list of conditions and the following disclaimer.

		* Redistributions in binary form must reproduce the above copyright notice, 
		this list of conditions and the following disclaimer in the documentation 
		and/or other materials provided with the distribution.

		* Neither the name of the DXFramework project nor the names of its 
		contributors may be used to endorse or promote products derived from this 
		software without specific prior written permission.

	THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND 
	ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED 
	WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE 
	DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR 
	ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES 
	(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; 
	LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON 
	ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT 
	(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS 
	SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/

#pragma once

#include "dxframework.h"

namespace dxf {
	/** Buttons go through four states:
		up --> pressed --> down --> released
	*/
	enum eButtonState {
		BUTTON_UP,			///< button is up now and was up last frame
		BUTTON_PRESSED,		///< button is down now and was up last frame
		BUTTON_DOWN,		///< button is down now and was down last frame
		BUTTON_RELEASED,	///< button is up now and was down last frame
	};

	enum eMouseButton {
		MBUTTON_LEFT,		///< left mouse button
		MBUTTON_RIGHT,		///< right mouse button
		MBUTTON_MIDDLE,		///< middle mouse button
		MBUTTON_SIDE1,		///< ?? side buttons?
		MBUTTON_SIDE2,		///< ?? side buttons?
	};

	/** This structure enumerates the capabilities of the joystick.  You can test this 
		to see what is available on the joystick.  The joystick is detected at program 
		startup and cannot be changed after the program is running.  This is a 
		limitation to simplify code and will be hopefully improved in the future.
	*/
	struct JoystickCaps {
		bool enabled;		///< false if no joystick present
		bool x;				///< has x axis
		bool y;				///< has y axis
		bool z;				///< has z axis
		bool xr;			///< has x rotation axis
		bool yr;			///< has y rotation axis
		bool zr;			///< has z rotation axis
		int povCount;		///< number of point-of-view inputs, 0 for none
		int sliderCount;	///< number of sliders, 0 for none
	};

	/** The controller class is an abstraction of keyboard, mouse, and joystick input. 
		It is created by the game class.	
	*/
	class Controller {
	public:
		Controller();

		HRESULT Load();
		void Unload();

		void Poll(); ///< must be called each frame

		void KeyboardProc( UINT nChar, bool bKeyDown, bool bAltDown, void* pUserContext );
		void MouseProc( bool bLeftButtonDown, bool bRightButtonDown, bool bMiddleButtonDown, 
			bool bSideButton1Down, bool bSideButton2Down, INT nMouseWheelDelta, INT xPos, INT yPos, void* pUserContext );

		/** Use to check the state of a key specified by the passed virtual key code.
		*/
		eButtonState CheckKeyboard(BYTE key);
		/** Use to check the state of a mouse button specified by the passed parameter.
		*/
		eButtonState CheckMouse(eMouseButton button);
		/** Use to see how much the mouse moved last frame.
		*/
		int GetMouseWheelDelta();

		/** Use to set a new location for the mouse.
		*/
		void SetMousePosition(int x, int y);
		/** Returns the back buffer coordinates where the mouse is pointing.
		*/
		POINT GetMousePosition();

		void BufferedInput(wchar_t key);
		
		/** Used to retrieve buffered input, clearing the buffered input buffer in the process.
		*/
		void GetBufferedInput(std::wstring& input);

		/** Use to check the state of a joystick button specified by the passed parameter.
		*/
		eButtonState CheckJoystick(int button);
		/** Returns a snapshot of the current joystick state
			Right click DIJOYSTATE2 and select "Go To Declaration" for more information on 
			that structure.
		*/
		const DIJOYSTATE2* GetJoystickState();

		static Controller* pController;
	private:
		unsigned current;

		std::bitset<256> keyboardRaw;
		std::bitset<256> keyboard[2];
		std::wstring bufferedInput;

		std::bitset<5> mouseRaw;
		std::bitset<5> mouse[2];
		int mouseWheelDelta;
		POINT mousePos;

		DIJOYSTATE2 jsRaw;
		DIJOYSTATE2 js[2];
	};

	void DXFPollInput();
	/** Use to check the state of a key specified by the passed virtual key code.
	*/
	eButtonState DXFCheckKeyboard(BYTE key);
	/** Used to retrieve buffered input, clearing the buffered input buffer in the process.
	*/
	void DXFGetBufferedInput(std::wstring& input);
	/** Use to check the state of a mouse button specified by the passed parameter.
	*/
	eButtonState DXFCheckMouse(eMouseButton button);
	/** Use to see how much the mouse moved last frame.
	*/
	int DXFGetMouseWheelDelta();
	/** Returns the back buffer coordinates where the mouse is pointing.
	*/
	POINT DXFGetMousePosition();
	/** Finds out what capabilities the joystick has.  See the JoystickCaps structure documentation.
	*/
	const JoystickCaps* DXFGetJoystickCapabilities();
	/** Use to check the state of a joystick button specified by the passed parameter.
	*/
	eButtonState DXFCheckJoystick(int button);
	/** Returns a snapshot of the current joystick state
	*/
	const DIJOYSTATE2* DXFGetJoystickState();

} // namespace dxf
