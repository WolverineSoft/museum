/*	DXFramework Copyright (c) 2005, Jonathan Voigt, University of Michigan.
	See http://dxframework.sourceforge.net/ for a list of contributors.
	All rights reserved.

	Redistribution and use in source and binary forms, with or without modification, 
	are permitted provided that the following conditions are met:

		* Redistributions of source code must retain the above copyright notice, 
		this list of conditions and the following disclaimer.

		* Redistributions in binary form must reproduce the above copyright notice, 
		this list of conditions and the following disclaimer in the documentation 
		and/or other materials provided with the distribution.

		* Neither the name of the DXFramework project nor the names of its 
		contributors may be used to endorse or promote products derived from this 
		software without specific prior written permission.

	THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND 
	ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED 
	WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE 
	DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR 
	ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES 
	(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; 
	LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON 
	ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT 
	(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS 
	SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/

#pragma once

#include "dxframework.h"
#include "dxf_font.h"
#include "dxf_sprite.h"
#include "dxf_texture.h"

namespace dxf {
	// Define the CommandFunction which we'll call to process commands
	typedef void (*CommandFunction)(std::vector<std::wstring>& argv);

	// Used to store a map from command name to function handler for that command
	typedef std::map<std::wstring, CommandFunction> CommandMap;
	typedef CommandMap::const_iterator CommandMapConstIter;

	/** Console class to assist in debugging and low level control of DXFramework 
		applications. 
	*/
	class Console {
	public:
		Console();

		HRESULT Load();
		void Unload();

		inline bool Active() const;	///< returns true if console is currently on
		inline void Activate();		///< unconditionally turns on console
	
		/** Registers a new command using the function pointer.  If the first argument of a 
			command typed in to the console matches (or partially matches) the first 
			parameter passed here, the function passed as the second parameter is called 
			with the tokenized command line.
		*/
		void RegisterCommand(const wchar_t* command, CommandFunction function);
		/** Displays all currently registered commands in the console output.
		*/
		void ListCommands() const;

		void Update();
		bool Render2D();

		void OnResetDevice(const D3DSURFACE_DESC* pBackBufferSurfaceDesc);

		const Font* GetFont();

		static Console* pConsole;

		/** Console output string stream.  Anything added to this string will be output to 
			the console output window.  Output is flushed when a newline character is 
			encountered.  If a newline character is not specified, the output will stay 
			cached and not appear in the output window.
		*/
		static std::wostringstream output;

	private:

		int TokenizeCommandLine(std::vector<std::wstring>& argv);
		bool FindCommand(std::vector<std::wstring>& argv);

		bool active;
		std::list<std::wstring> display;
		std::wstring commandLine;
		CommandMap commandMap;
		Font font;
		int rows;
		Sprite upper;
		Sprite lower;
		Texture texture;
	};

	void DXFUpdateConsole();
	void DXFRenderConsole();
	/** Registers a new command using the function pointer.  If the first argument of a 
		command typed in to the console matches (or partially matches) the first 
		parameter passed here, the function passed as the second parameter is called 
		with the tokenized command line.
	*/
	void DXFRegisterCommand(const wchar_t* command, CommandFunction function);
} // namespace dxf
