/*	DXFramework Copyright (c) 2005, Jonathan Voigt, University of Michigan.
	See http://dxframework.sourceforge.net/ for a list of contributors.
	All rights reserved.

	Redistribution and use in source and binary forms, with or without modification, 
	are permitted provided that the following conditions are met:

		* Redistributions of source code must retain the above copyright notice, 
		this list of conditions and the following disclaimer.

		* Redistributions in binary form must reproduce the above copyright notice, 
		this list of conditions and the following disclaimer in the documentation 
		and/or other materials provided with the distribution.

		* Neither the name of the DXFramework project nor the names of its 
		contributors may be used to endorse or promote products derived from this 
		software without specific prior written permission.

	THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND 
	ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED 
	WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE 
	DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR 
	ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES 
	(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; 
	LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON 
	ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT 
	(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS 
	SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/

#pragma once

/** Global information to include everywhere */

#define DXF_VERSION_MAJOR 0
#define DXF_VERSION_MINOR 9
#define DXF_VERSION_MICRO 4
#define DXF_VERSION_STRING L"0.9.4"

// Handy macro used to quell warnings about unused parameters
#ifndef unused
#define unused(x) (void)(x)
#endif //unused

// Headers
#include "dxstdafx.h"

#define DIRECTINPUT_VERSION 0x0800
#include <dinput.h>

#include <dshow.h>

#pragma warning( disable : 4530 )
#include <vector>
#include <string>
#include <map>
#include <list>
#include <algorithm>
#include <vector>
#include <stack>
#include <queue>
#include <sstream>
#include <bitset>
#pragma warning( default : 4530 )


/* some common colors */
const D3DCOLOR  BLACK	= D3DCOLOR_ARGB(255,0,0,0);			///< definition of a often used color
const D3DCOLOR  RED		= D3DCOLOR_ARGB(255,255,0,0);		///< definition of a often used color
const D3DCOLOR	GREEN	= D3DCOLOR_ARGB(255,0,255,0);		///< definition of a often used color
const D3DCOLOR	BLUE	= D3DCOLOR_ARGB(255,0,0,255);		///< definition of a often used color
const D3DCOLOR  MAGENTA = D3DCOLOR_ARGB(255,255,0,255);		///< definition of a often used color
const D3DCOLOR  CYAN	= D3DCOLOR_ARGB(255,0,255,255);		///< definition of a often used color
const D3DCOLOR  YELLOW	= D3DCOLOR_ARGB(255,255,255,0);		///< definition of a often used color
const D3DCOLOR  WHITE	= D3DCOLOR_ARGB(255,255,255,255);	///< definition of a often used color

/* useful for directions */
#define DIR_NONE		0
#define DIR_UP			1
#define DIR_DOWN		2
#define DIR_LEFT		3
#define DIR_UPLEFT		4 // DIR_UP   + DIR_LEFT
#define DIR_DOWNLEFT	5 // DIR_DOWN + DIR_LEFT
#define DIR_RIGHT		6
#define DIR_UPRIGHT		7 // DIR_UP   + DIR_RIGHT
#define DIR_DOWNRIGHT	8 // DIR_DOWN + DIR_RIGHT
