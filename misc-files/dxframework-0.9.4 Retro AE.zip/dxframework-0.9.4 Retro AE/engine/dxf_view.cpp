/*	DXFramework Copyright (c) 2005, Jonathan Voigt, University of Michigan.
	See http://dxframework.sourceforge.net/ for a list of contributors.
	All rights reserved.

	Redistribution and use in source and binary forms, with or without modification, 
	are permitted provided that the following conditions are met:

		* Redistributions of source code must retain the above copyright notice, 
		this list of conditions and the following disclaimer.

		* Redistributions in binary form must reproduce the above copyright notice, 
		this list of conditions and the following disclaimer in the documentation 
		and/or other materials provided with the distribution.

		* Neither the name of the DXFramework project nor the names of its 
		contributors may be used to endorse or promote products derived from this 
		software without specific prior written permission.

	THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND 
	ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED 
	WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE 
	DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR 
	ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES 
	(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; 
	LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON 
	ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT 
	(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS 
	SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/

#include "dxf_view.h"
#include "dxf_model.h"
#include "dxf_font.h"
#include "dxf_texture.h"
#include "dxf_console.h"
#include "dxf_gui.h"

HRESULT CALLBACK OnCreateDevice( IDirect3DDevice9* pd3dDevice, const D3DSURFACE_DESC* pBackBufferSurfaceDesc, void* pUserContext ) {
	return dxf::View::pView->OnCreateDevice(pd3dDevice, pBackBufferSurfaceDesc, pUserContext);
}

HRESULT CALLBACK OnResetDevice( IDirect3DDevice9* pd3dDevice, const D3DSURFACE_DESC* pBackBufferSurfaceDesc, void* pUserContext ) {
	return dxf::View::pView->OnResetDevice(pd3dDevice, pBackBufferSurfaceDesc, pUserContext);
}

void CALLBACK OnLostDevice( void* pUserContext ) {
	if (dxf::View::pView) dxf::View::pView->OnLostDevice(pUserContext);
}

void CALLBACK OnDestroyDevice( void* pUserContext ){
	if (dxf::View::pView) dxf::View::pView->OnDestroyDevice(pUserContext);
}

void CALLBACK OnFrameRender( IDirect3DDevice9* pd3dDevice, double fTime, float fElapsedTime, void* pUserContext ) {
	dxf::View::pView->OnFrameRender(pd3dDevice, fTime, fElapsedTime, pUserContext);
}

bool CALLBACK IsDeviceAcceptable( D3DCAPS9* pCaps, D3DFORMAT AdapterFormat, 
                                  D3DFORMAT BackBufferFormat, bool bWindowed, void* pUserContext )
{
    // Skip backbuffer formats that don't support alpha blending
    IDirect3D9* pD3D = DXUTGetD3DObject(); 
    if( FAILED( pD3D->CheckDeviceFormat( pCaps->AdapterOrdinal, pCaps->DeviceType,
                    AdapterFormat, D3DUSAGE_QUERY_POSTPIXELSHADER_BLENDING, 
                    D3DRTYPE_TEXTURE, BackBufferFormat ) ) )

        return false;

    // Must support pixel shader 1.1
    //if( pCaps->PixelShaderVersion < D3DPS_VERSION( 1, 1 ) )
    //    return false;

    return true;
}

bool CALLBACK ModifyDeviceSettings( DXUTDeviceSettings* pDeviceSettings, const D3DCAPS9* pCaps, void* pUserContext ) {
	return dxf::View::pView->ModifyDeviceSettings(pDeviceSettings, pCaps, pUserContext);
}

namespace dxf {
	View* View::pView = 0;

	View::View() {
		assert(!pView);
		pd3dxSprite = 0;
	}

	void View::Load(int initialWidth, int initialHeight, bool forceResolution) {
		assert(!pView);
		pView = this;

		this->initialWidth = initialWidth;
		this->initialHeight = initialHeight;
		this->forceResolution = forceResolution;

		clear = true;
		clearRect.x1 = 0;
		clearRect.x2 = initialWidth;
		clearRect.y1 = 0;
		clearRect.y2 = initialHeight;
		clearColor = BLACK;

		DXUTSetCallbackDeviceCreated( ::OnCreateDevice );
		DXUTSetCallbackDeviceReset( ::OnResetDevice );
		DXUTSetCallbackDeviceLost( ::OnLostDevice );
		DXUTSetCallbackDeviceDestroyed( ::OnDestroyDevice );
		DXUTSetCallbackFrameRender( ::OnFrameRender );
	}

	HRESULT View::Init(const wchar_t* windowName) {
		HRESULT hr;
		V_RETURN(DXUTCreateWindow(windowName));
		DXUTGetEnumeration()->SetRequirePostPixelShaderBlending(false);
		V_RETURN(DXUTCreateDevice( D3DADAPTER_DEFAULT, true, initialWidth, initialHeight, IsDeviceAcceptable, ::ModifyDeviceSettings));
		return S_OK;
	}

	void View::Unload() {
		assert(pView);
		pView = 0;

		SAFE_RELEASE(pd3dxSprite);
	}

	bool View::ModifyDeviceSettings( DXUTDeviceSettings* pDeviceSettings, const D3DCAPS9* pCaps, void* pUserContext ) {
		// If device doesn't support HW T&L or doesn't support 1.1 vertex shaders in HW 
		// then switch to SWVP.
		if( (pCaps->DevCaps & D3DDEVCAPS_HWTRANSFORMANDLIGHT) == 0 ||
			pCaps->VertexShaderVersion < D3DVS_VERSION(1,1) )
		{
			pDeviceSettings->BehaviorFlags = D3DCREATE_SOFTWARE_VERTEXPROCESSING;
		}

		// Debugging vertex shaders requires either REF or software vertex processing 
		// and debugging pixel shaders requires REF.  
#ifdef DEBUG_VS
		if( pDeviceSettings->DeviceType != D3DDEVTYPE_REF )
		{
			pDeviceSettings->BehaviorFlags &= ~D3DCREATE_HARDWARE_VERTEXPROCESSING;
			pDeviceSettings->BehaviorFlags &= ~D3DCREATE_PUREDEVICE;                            
			pDeviceSettings->BehaviorFlags |= D3DCREATE_SOFTWARE_VERTEXPROCESSING;
		}
#endif
#ifdef DEBUG_PS
		pDeviceSettings->DeviceType = D3DDEVTYPE_REF;
#endif
		// For the first device created if its a REF device, optionally display a warning dialog box
		static bool s_bFirstTime = true;
		if( s_bFirstTime )
		{
			s_bFirstTime = false;
			if( pDeviceSettings->DeviceType == D3DDEVTYPE_REF )
				DXUTDisplaySwitchingToREFWarning();
		}

		if (forceResolution) {
			pDeviceSettings->pp.BackBufferWidth = initialWidth;
			pDeviceSettings->pp.BackBufferHeight = initialHeight;
		}

		return true;
	}

	HRESULT View::OnCreateDevice( IDirect3DDevice9* pd3dDevice, const D3DSURFACE_DESC* pBackBufferSurfaceDesc, void* pUserContext ) {
		HRESULT hr;

		GUI* pGUI = DXFGetGUI();
		if (pGUI) {
			V_RETURN(pGUI->OnCreateDevice(pd3dDevice, pBackBufferSurfaceDesc));
		}
		V_RETURN(Font::OnCreateDevice());
		V_RETURN(Texture::OnCreateDevice());

		V_RETURN(D3DXCreateSprite(DXUTGetD3DDevice(), &pd3dxSprite));
		return S_OK;
	}

	HRESULT View::OnResetDevice( IDirect3DDevice9* pd3dDevice, const D3DSURFACE_DESC* pBackBufferSurfaceDesc, void* pUserContext ) {
		HRESULT hr;

		D3DRECT r;
		r.x1 = 0;
		r.x2 = pBackBufferSurfaceDesc->Width;
		r.y1 = 0;
		r.y2 = pBackBufferSurfaceDesc->Height;
		SetClearRect(r);

		GUI* pGUI = DXFGetGUI();
		if (pGUI) {
			V_RETURN(pGUI->OnResetDevice(pd3dDevice, pBackBufferSurfaceDesc));
		}
		V_RETURN(pd3dxSprite->OnResetDevice());
		V_RETURN(Font::OnResetDevice());
		if (Console::pConsole) Console::pConsole->OnResetDevice(pBackBufferSurfaceDesc);
		Model::pModel->Resize(pBackBufferSurfaceDesc);
		return S_OK;
	}

	void View::OnLostDevice( void* pUserContext ) {
		GUI* pGUI = DXFGetGUI();
		if (pGUI) {
			pGUI->OnLostDevice();
		}
		if (pd3dxSprite) pd3dxSprite->OnLostDevice();
		Font::OnLostDevice();
	}

	void View::OnDestroyDevice( void* pUserContext ) {
		GUI* pGUI = DXFGetGUI();
		if (pGUI) {
			pGUI->OnDestroyDevice();
		}
		Font::OnDestroyDevice();
		Texture::OnDestroyDevice();

		SAFE_RELEASE(pd3dxSprite);
	}

	void View::OnFrameRender( IDirect3DDevice9* pd3dDevice, double fTime, float fElapsedTime, void* pUserContext ) {
		HRESULT hr;

		// Clear the render target and the zbuffer 
		if (clear) {
			V( pd3dDevice->Clear(1, &clearRect, D3DCLEAR_TARGET | D3DCLEAR_ZBUFFER, clearColor, 1.0f, 0) );
		}

		// Render the scene
		if( SUCCEEDED( pd3dDevice->BeginScene() ) ) {
			pd3dDevice->SetRenderState(D3DRS_ZENABLE,D3DZB_FALSE);

			// Background 2D
			V(pd3dxSprite->Begin(D3DXSPRITE_ALPHABLEND));
			DXFRenderPre2D(fTime, fElapsedTime);
			V(pd3dxSprite->End());

			// 3D
			pd3dDevice->SetRenderState(D3DRS_ZENABLE,D3DZB_TRUE);
			DXFRender3D(fTime, fElapsedTime);

			// Foreground 2D
			V(pd3dxSprite->Begin(D3DXSPRITE_ALPHABLEND));	
			DXFRender2D(fTime, fElapsedTime);
			V(pd3dxSprite->End());

			// GUI
			GUI* pGUI = DXFGetGUI();
			if (pGUI) {
				V(pGUI->OnFrameRender(fElapsedTime));
			}

			// Console
			V(pd3dxSprite->Begin(D3DXSPRITE_ALPHABLEND));
			DXFRenderConsole();
			V(pd3dxSprite->End());

			V(pd3dDevice->EndScene());
		}
	}

	void View::SetClear(bool clear) { 
		this->clear = clear; 
	}

	void View::SetClearColor(D3DCOLOR clearColor) { this->clearColor = clearColor; }
	void View::SetClearRect(const D3DRECT& clearRect) { this->clearRect = clearRect; }
	ID3DXSprite* View::GetD3DXSprite() { return pd3dxSprite; }
	ID3DXSprite* DXFGetD3DXSprite() { return View::pView->GetD3DXSprite(); }
	void DXFSetClear(bool clearEachFrame) { View::pView->SetClear(clearEachFrame); }
	void DXFSetClearColor(D3DCOLOR clearColor) { View::pView->SetClearColor(clearColor); }
	void DXFSetClearRect(const D3DRECT& clearRect) { View::pView->SetClearRect(clearRect); }
} // namespace dxf