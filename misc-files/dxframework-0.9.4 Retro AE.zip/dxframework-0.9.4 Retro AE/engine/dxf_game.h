/*	DXFramework Copyright (c) 2005, Jonathan Voigt, University of Michigan.
	See http://dxframework.sourceforge.net/ for a list of contributors.
	All rights reserved.

	Redistribution and use in source and binary forms, with or without modification, 
	are permitted provided that the following conditions are met:

		* Redistributions of source code must retain the above copyright notice, 
		this list of conditions and the following disclaimer.

		* Redistributions in binary form must reproduce the above copyright notice, 
		this list of conditions and the following disclaimer in the documentation 
		and/or other materials provided with the distribution.

		* Neither the name of the DXFramework project nor the names of its 
		contributors may be used to endorse or promote products derived from this 
		software without specific prior written permission.

	THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND 
	ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED 
	WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE 
	DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR 
	ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES 
	(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; 
	LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON 
	ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT 
	(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS 
	SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/

#pragma once

#include "dxframework.h"
#include "dxf_view.h"
#include "dxf_console.h"
#include "dxf_model.h"
#include "dxf_controller.h"

namespace dxf {
	/** Client applications define these two functions which are called when loading the
		engine.  The RegisterStates function defines the states, RegisterCommands defines
		custom commands for the console.
	*/
	class RegistrarInterface {
	public:
		/** This function is called when the engine first loads.  The purpose of this
			function is to allow the client (application) to define states in the client
			code and register pointers to those states in the engine so that the
			DXFramework state machine can transition from state to state.

			An example body of this function is:
				dxf::DXFRegisterState(kTitle, &title);
				dxf::DXFRegisterState(kKeyboard, &keyboard);

			The first line here maps the string constant "Title" (kTitle) with the pointer
			to the title state object.

			The second line registers the string constand "Keyboard" (kKeyboard) with the
			pointer to the keyboard state object.

			To change states in the future, simply call the function DXFChangeState with one
			of the registered string constants like so:
				dxf::DXFChangeState(Registrar::kKeyboard);

			This line changes the state to the keyboard state.

			Finally, the first registered state is the initial state, which is why title is
			registered before keyboard.

			See also DXFRegisterState, DXFChangeState, GameState
		*/
		virtual void RegisterStates() = 0;

		/** This function is called when the engine first loads and is for allowing the
			client (application) to define custom commands for the console interface.

			An example body of this function is:
				dxf::DXFRegisterCommand(L"add", &add);	
			
			This adds a command "add" to the console that calls the function pointer add()
			with a vector of strings of all of the command line tokens.

			You need not define this function.
		*/
		virtual void RegisterCommands() {};
	};

	/** The game class is the top level container for the DXFramework engine.  
	*/
	class Game {
	public:
		Game();

		LRESULT MsgProc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam, bool* pbNoFurtherProcessing, void* pUserContext);

		static Game* pGame;

		/** Load the engine so it is ready for use.

			@param windowName The name used in the title bar/task manager for the application.\
			@param pRegistrar a pointer to a client-owned registrar that handles registering states
			and custom commands.
			@param initialWidth Initial window/back buffer width to use for the application. A safe
			value is 800
			@param initialHeight initial window/back buffer height for the application. A safe value
			is 600
			@param forceResolution Using true here will force the window size to be the initial size.
			Use with caution.  If the user's monitor cannot display this resolution, the application
			will fail to start.  If false is passed here, the back buffer size may not be constant,
			it will be able to change during a run, so you must program to allow for this.
		*/
		HRESULT Load(const wchar_t* windowName, RegistrarInterface* pRegistrar, int initialWidth, int initialHeight, bool forceResolution = false);

		/** Run the application.  Start the real-time simulation.
			This returns when the application is finished.
		*/
		void Run();

		/** Remove the engine from memory.  Returns an exit code.
		*/
		int Unload();

	private:
		View view;
		Controller controller;
		Model model;
		Console console;
		CSoundManager sound;
	};
} // namespace dxf