/*	DXFramework Copyright (c) 2005, Jonathan Voigt, University of Michigan.
	See http://dxframework.sourceforge.net/ for a list of contributors.
	All rights reserved.

	Redistribution and use in source and binary forms, with or without modification, 
	are permitted provided that the following conditions are met:

		* Redistributions of source code must retain the above copyright notice, 
		this list of conditions and the following disclaimer.

		* Redistributions in binary form must reproduce the above copyright notice, 
		this list of conditions and the following disclaimer in the documentation 
		and/or other materials provided with the distribution.

		* Neither the name of the DXFramework project nor the names of its 
		contributors may be used to endorse or promote products derived from this 
		software without specific prior written permission.

	THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND 
	ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED 
	WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE 
	DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR 
	ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES 
	(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; 
	LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON 
	ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT 
	(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS 
	SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/

#include "dxf_texture.h"
#include "dxf_tools.h"
#include "dxf_game.h"

namespace dxf {
	std::map<std::wstring, TextureInfo*> Texture::infoMap;	

	Texture::Texture() {
		pInfo = 0;
		pPixels = 0;		
		pitch = 0;			
	}

	HRESULT Texture::CreateFromFile(const std::wstring& filename, bool multipleLevel, D3DCOLOR transparent) {
		assert(!pInfo);

		HRESULT hr;

		// Try loading from texture cache
		if (CheckInfoMap(filename, multipleLevel, transparent)) {
			pInfo = infoMap[filename];
			++(pInfo->count);
			return S_OK;
		}
		
		pInfo = new TextureInfo;
		if (!pInfo) return E_OUTOFMEMORY;
		infoMap[filename] = pInfo;

		pInfo->filename = filename;
		pInfo->multipleLevel = multipleLevel;
		pInfo->transparent = transparent;
		pInfo->count = 1;
		pInfo->saved = true;

		// FIXME: old engine used to try to load from resource first, I removed this because it doesn't work with
		// .png formats and would clash with CreateFromFile name.  the relevant code should be inserted in to
		// a new CreateFromBMPResource function

		std::wstring pathname(L"../media/");
		pathname += filename;

		if (multipleLevel) {
			// For most 3D applications, faster since it contains multiple levels of texture detail
			V_RETURN(D3DXCreateTextureFromFileEx(DXUTGetD3DDevice(), pathname.c_str(), 
				0, 0, D3DX_DEFAULT, 0, D3DFMT_A8R8G8B8, D3DPOOL_MANAGED, D3DX_DEFAULT, D3DX_DEFAULT,
				transparent, &(pInfo->imageInfo), 0, &(pInfo->pTexture)));
		} else {
			V_RETURN(D3DXCreateTextureFromFileEx(DXUTGetD3DDevice(), pathname.c_str(), 
				0, 0, 1, 0, D3DFMT_A8R8G8B8, D3DPOOL_MANAGED, D3DX_FILTER_NONE, D3DX_DEFAULT,
				transparent, &(pInfo->imageInfo), 0, &(pInfo->pTexture)));
		}
		return S_OK;
	}

	HRESULT Texture::CreateNew(const std::wstring& filename, unsigned width, unsigned height) {
		assert(!pInfo);

		HRESULT hr;

		// Try loading from texture cache
		if (CheckInfoMap(filename, false, 0)) {
			pInfo = infoMap[filename];
			++(pInfo->count);
			return S_OK;
		}

		pInfo = new TextureInfo;
		if (!pInfo) return E_OUTOFMEMORY;
		infoMap[filename] = pInfo;

		ZeroMemory(&(pInfo->imageInfo), sizeof(D3DXIMAGE_INFO));
		pInfo->imageInfo.Width = width;
		pInfo->imageInfo.Height = height;
		pInfo->filename = filename;
		pInfo->multipleLevel = false;
		pInfo->transparent = 0;
		pInfo->count = 1;
		pInfo->saved = false;

		V_RETURN(D3DXCreateTexture(DXUTGetD3DDevice(), width, height, 0, D3DX_DEFAULT, D3DFMT_A8R8G8B8, D3DPOOL_MANAGED, &(pInfo->pTexture)));
		return S_OK;
	}

	void Texture::Unload() {
		assert(pInfo);

		--(pInfo->count);

		if (!pInfo->count) {
			TextureInfoMapIter iter = infoMap.begin();
			while(iter != infoMap.end()) {
				if (iter->second == pInfo) {
					infoMap.erase(iter);
					break;
				}
				++iter;
			}
			SAFE_RELEASE(pInfo->pTexture);
			SAFE_DELETE(pInfo);
		}
		pInfo = 0;
	}

	bool Texture::CheckInfoMap(const std::wstring& filename, bool multipleLevel, D3DCOLOR transparent) {
		if (infoMap.size()) {
			if (infoMap.find(filename) != infoMap.end()) {
				// make sure we haven't loaded it with other qualities
				assert((multipleLevel == infoMap[filename]->multipleLevel) && (transparent == infoMap[filename]->transparent));
				return true;
			}
		}
		return false;
	}

	unsigned Texture::GetWidth() const {
		return pInfo->imageInfo.Width;
	}

	unsigned Texture::GetHeight() const {
		return pInfo->imageInfo.Height;
	}

	std::wstring Texture::GetFilename() {
		return pInfo->filename;
	}

	IDirect3DTexture9* Texture::GetD3DTexture() {
		return pInfo->pTexture;
	}

	HRESULT Texture::BeginDrawing() {
		assert(!pInfo->multipleLevel);

		// Lock the texture memory
		ZeroMemory(&lockedRect, sizeof(lockedRect));

		// Lock the whole texture
		HRESULT hr;
		V_RETURN(pInfo->pTexture->LockRect(0, &lockedRect, NULL, 0));

		pitch = lockedRect.Pitch; // Pitch of the texture
		pPixels = (unsigned char *)lockedRect.pBits; // Pointer to texture memory

		return S_OK;
	}

	HRESULT Texture::EndDrawing() {
		assert(!pInfo->multipleLevel);

		// Unlock the texture
		HRESULT hr;
		V_RETURN(pInfo->pTexture->UnlockRect(0)); 

		pitch = 0;
		pPixels = NULL;
		return S_OK;
	}

	HRESULT Texture::SaveToFile(TextureInfo* pInfo) {
		assert(!pInfo->multipleLevel);

		HRESULT hr;

		std::wstring pathname(L"../media/");
		pathname += pInfo->filename;

		V_RETURN(D3DXSaveTextureToFile(pathname.c_str(), D3DXIFF_BMP, pInfo->pTexture, 0));
		return S_OK;
	}

	void Texture::ObtainARGBFromColor(DWORD color, unsigned char *p_A, char *p_R, unsigned char *p_G, unsigned char *p_B) {
		// Each components are 8 bits
		*p_B = (unsigned char) (color & 255);
		color = color >> 8;

		*p_G = (unsigned char) (color & 255);
		color = color >> 8;

		*p_R = (unsigned char) (color & 255);
		color = color >> 8;

		*p_A = (unsigned char) (color & 255);
	}

	void Texture::PutPixel(unsigned x, unsigned y, DWORD color) {
		assert(pPixels);

		if ((x < 0) || (y < 0) || (x >= pInfo->imageInfo.Width) || (y >= pInfo->imageInfo.Height)) return;
		*((DWORD *)&pPixels[y * pitch + (x << 2)]) = color;
	}

	DWORD Texture::GetPixel(unsigned x, unsigned y) {
		assert(pPixels);

		if ((x < 0) || (y < 0) || (x >= pInfo->imageInfo.Width) || (y >= pInfo->imageInfo.Height)) return 0;
		return *((DWORD *)&pPixels[y * pitch + (x << 2)]);
	}

	void Texture::Bar(unsigned x1, unsigned y1, unsigned x2, unsigned y2, DWORD color) {
		assert(pPixels);

		// Perform simple clip
		if (x1 < 0) x1 = 0;
		if (y1 < 0) y1 = 0;
		if (x2 >= pInfo->imageInfo.Width) x2 = pInfo->imageInfo.Width - 1;
		if (y2 >= pInfo->imageInfo.Height) y2 = pInfo->imageInfo.Height - 1;

		if ((x1 >= pInfo->imageInfo.Width) || (y1 >= pInfo->imageInfo.Height) || (x2 < 0) || (y2 < 0) ) return;
		unsigned i, j;

		// The easiest way to draw bar
		for (i = y1; i <= y2; i++) {
			for (j = x1; j <= x2; j++) {
				*((DWORD *)&pPixels[i * pitch + (j << 2)]) = color;
			}
		}
	}

	void Texture::Rectangle(unsigned x1, unsigned y1, unsigned x2, unsigned y2, DWORD color) {
		unsigned i;
		// Draw top and bottom border
		for (i = x1; i <= x2; i++) {
			PutPixel(i, y1, color); 
			PutPixel(i, y2, color);
		}

		// Draw left and right border
		for (i = y1; i <= y2; i++) {
			PutPixel(x1, i, color);
			PutPixel(x2, i, color);
		}
	}

	void Texture::Line(unsigned x1, unsigned y1, unsigned x2, unsigned y2, DWORD color) {
		// Use Bresenham algorithm
		int currentX = x1;
		int currentY = y1;
		int deltaX;
		int deltaY;
		int signDX;
		int signDY;
		int temp;
		int num2DYAfter;
		int num2DYm2DXAfter;
		bool swapXY = false;

		// Check if it's from top to bottom or bottom to top or horizontal
		if (y2 < y1) {
			signDY = -1; 
		} else if (y1 < y2) {
			signDY = 1; 
		} else {
			signDY = 0;
		}

		// Check if it's from left to right or right to left or verticle
		if (x2 < x1) {
			signDX = -1; 
		} else if (x1 < x2) {
			signDX = 1; 
		} else {
			signDX = 0;
		}

		PutPixel(x1, y1, color);

		deltaX = abs(static_cast<int>(x2) - static_cast<int>(x1));
		deltaY = abs(static_cast<int>(y2) - static_cast<int>(y1));

		// Temporary for calculation
		temp = 2 * (deltaY - deltaX);

		// We want deltaX to be > deltaY, if not, we need to reverse the drawing
		if (deltaY > deltaX) {
			std::swap(deltaX, deltaY);
			swapXY = true;
		}

		// deltaX > deltaY, after swap
		num2DYAfter = 2 * deltaY;
		num2DYm2DXAfter = 2 * (deltaY - deltaX);
		
		// Loop along the longer axis to draw pixels
		for (int i = 1; i <= deltaX; i++) {
			if (temp < 0) {
				if (swapXY) {
					currentY += signDY;
				} else {
					currentX += signDX;
				}

				PutPixel(currentX, currentY, color);
				temp += num2DYAfter;
			} else {
				currentX += signDX;
				currentY += signDY;

				PutPixel(currentX, currentY, color);
				temp += num2DYm2DXAfter;
			}
		}
	}

	void Texture::Circle(unsigned x, unsigned y, int radius, DWORD color) {
		// Use Midpoint Circle algorithm
		int currentDX = 0;
		int currentDY = radius;
		int tempCal = 1 - radius;

		// Plot 4 starting points
		PutPixel(x, y + radius, color);
		PutPixel(x, y - radius, color);
		PutPixel(x + radius, y, color);
		PutPixel(x - radius, y, color);

		while (currentDX < currentDY) {
			currentDX++;
			if (tempCal < 0) {
				tempCal += 2 * currentDX + 1;
			} else {
				currentDY--;
				tempCal += 2 * (currentDX - currentDY) + 1;
			}

			// Plot 8 points
			PutPixel(x + currentDX, y + currentDY, color);
			PutPixel(x + currentDX, y - currentDY, color);
			PutPixel(x - currentDX, y + currentDY, color);
			PutPixel(x - currentDX, y - currentDY, color);
			PutPixel(x + currentDY, y + currentDX, color);
			PutPixel(x + currentDY, y - currentDX, color);
			PutPixel(x - currentDY, y + currentDX, color);
			PutPixel(x - currentDY, y - currentDX, color);
		}
	}

	void Texture::Ellipse(unsigned x, unsigned y, int radiusX, int radiusY, DWORD color) {
		int radiusXP2 = radiusX * radiusX;
		int radiusYP2 = radiusY * radiusY;

		int radiusXP2m2 = radiusXP2 * 2;
		int radiusYP2m2 = radiusYP2 * 2;

		int currentDX = 0;
		int currentDY = radiusY;
		int tempX = 0;
		int tempY = radiusXP2m2 * radiusY;
		
		// Plot top and bottom most pixel
		PutPixel(x, y - radiusY, color);
		PutPixel(x, y + radiusY, color);

		int temp;

		// Draw the region where magnitude of the slope of the tangent line to the ellipse is less than 1
		temp = (int)round(radiusYP2 - (radiusXP2 * (radiusY - 0.25)));
		while (tempX < tempY) {
			currentDX++;
			tempX += radiusYP2m2;
			if (temp < 0) {
				temp += radiusYP2 + tempX;
			} else {
				currentDY--;
				tempY -= radiusXP2m2;
				temp += radiusYP2 + tempX - tempY;
			}
			PutPixel(x + currentDX, y + currentDY, color);
			PutPixel(x + currentDX, y - currentDY, color);
			PutPixel(x - currentDX, y + currentDY, color);
			PutPixel(x - currentDX, y - currentDY, color);
		}

		// Draw the rest
		temp = (int)round(radiusYP2 * (currentDX + 0.5) * (currentDX + 0.5) + radiusXP2 * (currentDY - 1) * (currentDY - 1) - radiusYP2 * radiusXP2);
		while (currentDY > 0) {
			currentDY--;
			tempY -= radiusXP2m2;
			if (temp > 0) {
				temp += radiusXP2 - tempY;
			} else {
				currentDX++;
				tempX += radiusYP2m2;
				temp += radiusXP2 - tempY + tempX;
			}
			PutPixel(x + currentDX, y + currentDY, color);
			PutPixel(x + currentDX, y - currentDY, color);
			PutPixel(x - currentDX, y + currentDY, color);
			PutPixel(x - currentDX, y - currentDY, color);
		}
	}

	void Texture::FloodFill(unsigned x, unsigned y, DWORD color) {

		// Check if the point is in the screen or not

		unsigned tempX, tempY;
		std::queue<unsigned> xQueue;
		std::queue<unsigned> yQueue;
		DWORD areaColor = GetPixel(x, y);
		xQueue.push(x);
		yQueue.push(y);

		while (!xQueue.empty()) {
			tempX = xQueue.front();
			tempY = yQueue.front();
			
			xQueue.pop();
			yQueue.pop();

			if ((tempX >= 0) && (tempY >= 0) && (tempX < pInfo->imageInfo.Width) && (tempY < pInfo->imageInfo.Height) && (GetPixel(tempX, tempY) == areaColor)) {
				PutPixel(tempX, tempY, color);

				xQueue.push(tempX - 1);
				yQueue.push(tempY);

				xQueue.push(tempX + 1);
				yQueue.push(tempY);

				xQueue.push(tempX);
				yQueue.push(tempY - 1);

				xQueue.push(tempX);
				yQueue.push(tempY + 1);
			}
		}
	}

	HRESULT Texture::OnCreateDevice() {
		HRESULT hr;
		
		TextureInfoMapIter iter = infoMap.begin();
		while(iter != infoMap.end()) {
			std::wstring pathname(L"../media/");
			pathname += iter->second->filename;

			if (iter->second->multipleLevel) {
				// For most 3D applications, faster since it contains multiple levels of texture detail
				V_RETURN(D3DXCreateTextureFromFileEx(DXUTGetD3DDevice(), pathname.c_str(), 
					0, 0, D3DX_DEFAULT, 0, D3DFMT_A8R8G8B8, D3DPOOL_MANAGED, D3DX_DEFAULT, D3DX_DEFAULT,
					iter->second->transparent, &(iter->second->imageInfo), 0, &(iter->second->pTexture)));
			} else {
				V_RETURN(D3DXCreateTextureFromFileEx(DXUTGetD3DDevice(), pathname.c_str(), 
					0, 0, 1, 0, D3DFMT_A8R8G8B8, D3DPOOL_MANAGED, D3DX_FILTER_NONE, D3DX_DEFAULT,
					iter->second->transparent, &(iter->second->imageInfo), 0, &(iter->second->pTexture)));
			}
			++iter;
		}

		return S_OK;
	}

	void Texture::OnDestroyDevice() {
		TextureInfoMapIter iter = infoMap.begin();
		while(iter != infoMap.end()) {
			if (!iter->second->saved) {
				SaveToFile(iter->second);
			}
			SAFE_RELEASE(iter->second->pTexture);
			++iter;
		}
	}
} // namespace dxf