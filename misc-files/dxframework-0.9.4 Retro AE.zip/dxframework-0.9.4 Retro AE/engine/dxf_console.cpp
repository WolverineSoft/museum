/*	DXFramework Copyright (c) 2005, Jonathan Voigt, University of Michigan.
	See http://dxframework.sourceforge.net/ for a list of contributors.
	All rights reserved.

	Redistribution and use in source and binary forms, with or without modification, 
	are permitted provided that the following conditions are met:

		* Redistributions of source code must retain the above copyright notice, 
		this list of conditions and the following disclaimer.

		* Redistributions in binary form must reproduce the above copyright notice, 
		this list of conditions and the following disclaimer in the documentation 
		and/or other materials provided with the distribution.

		* Neither the name of the DXFramework project nor the names of its 
		contributors may be used to endorse or promote products derived from this 
		software without specific prior written permission.

	THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND 
	ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED 
	WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE 
	DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR 
	ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES 
	(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; 
	LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON 
	ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT 
	(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS 
	SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/

#include "dxf_console.h"
#include "dxf_controller.h"

namespace dxf {
	bool gFPS = false;
	bool gMouse = false;

	void help(std::vector<std::wstring>& argv) {
		Console::pConsole->ListCommands();
	}

	void fps(std::vector<std::wstring>& argv) {
		gFPS = !gFPS;
	}

	void mouse(std::vector<std::wstring>& argv) {
		gMouse = !gMouse;
	}

	void quit(std::vector<std::wstring>& argv) {
		PostQuitMessage(0);
	}

	Console* Console::pConsole = 0;
	std::wostringstream Console::output;

	Console::Console() {
		assert(!pConsole);
	}

	HRESULT Console::Load() {
		assert(!pConsole);
		pConsole = this;

		HRESULT hr;

		V_RETURN(font.Load(L"HE_TERMINAL", 12, FW_NORMAL));

		rows = 15;

		V_RETURN(texture.CreateNew(L"whitepixel.bmp", 1, 1));
		V_RETURN(texture.BeginDrawing());
		texture.PutPixel(0,0,WHITE);
		V_RETURN(texture.EndDrawing());

		const D3DSURFACE_DESC* d = DXUTGetBackBufferSurfaceDesc();		

		V_RETURN(upper.CreateFromTexture(texture));
		upper.SetPosition(0, 0);
		upper.SetScaling(D3DXVECTOR2(static_cast<float>(d->Width), static_cast<float>(font.GetHeight()) * rows));
		upper.SetColor(D3DCOLOR_ARGB(225,255,255,255));
		
		V_RETURN(lower.CreateFromTexture(texture));
		lower.SetPosition(0, font.GetHeight() * rows);
		lower.SetScaling(D3DXVECTOR2(static_cast<float>(d->Width), static_cast<float>(font.GetHeight())));;
		lower.SetColor(D3DCOLOR_ARGB(225,128,128,128));

		// Add information lines
		output << L"DXFramework version " << DXF_VERSION_MAJOR << L"." << DXF_VERSION_MINOR << L"." << DXF_VERSION_MICRO;
#ifdef _DEBUG
		output << L" (_DEBUG)";
#endif
#ifdef NDEBUG
		output << L" (NDEBUG)";
#endif
#if _MSC_VER == 1200 
		output << L" (MSVC 6)";
#endif
#if _MSC_VER == 1300
		output << L" (MSVC .NET)";
#endif
		output << std::endl;

		output << DXUTGetDeviceStats() << std::endl;

		RegisterCommand(L"exit", &quit);
		RegisterCommand(L"fps", &fps);
		RegisterCommand(L"mouse", &mouse);
		RegisterCommand(L"help", &help);
		RegisterCommand(L"quit", &quit);

		active = false;
		return S_OK;
	}

	void Console::Unload() {
		assert(pConsole);
		pConsole = 0;
		upper.Unload();
		lower.Unload();
		texture.Unload();
		font.Unload();
	}

	void Console::RegisterCommand(const wchar_t* command, CommandFunction function) {
		commandMap[command] = function;
	}

	void Console::ListCommands() const {
		CommandMapConstIter iter = commandMap.begin();
		output << "Console commands: ";
		while (iter != commandMap.end()) {
			output << iter->first << " ";
			++iter;
		}
		output << std::endl;
	}

	inline bool Console::Active() const {
		return active;
	}

	inline void Console::Activate() {
		active = true;
	}

	void Console::Update() {
		// move output to display
		if (output.str().size()) {
			std::wstring::size_type pos = output.str().find('\n');
			while (pos != std::wstring::npos) {
				// found a newline
				std::wstring line = output.str().substr(0, pos);
				display.push_front(line);
				output.str(output.str().substr(pos + 1));
				pos = output.str().find('\n');
			}
		}

		std::wstring bufferedInput;
		// check to see if console hotkey was pressed
		if (DXFCheckKeyboard(VK_OEM_3) == BUTTON_PRESSED) {
			active = !active;
			// clear buffered input
			DXFGetBufferedInput(bufferedInput);
			bufferedInput = L"";
		}

		// don't do anything else if not active
		if (!active) return;
		
		DXFGetBufferedInput(bufferedInput);

		for (std::wstring::const_iterator iter = bufferedInput.begin(); iter != bufferedInput.end(); ++iter) {
			switch(*iter) {
				case '`': // ignore console hotkey
					break;

				case '\r':	// Return parses
					{
						std::vector<std::wstring> argv;
						int argc = TokenizeCommandLine(argv);
						if (argc) {
							if (argc < 0) {
								output << "Parsing error: unmatched quotes." << std::endl;
							} else {
								if (FindCommand(argv)) {
									CommandFunction pFunction = commandMap[argv[0]];
									assert(pFunction);	// putting an assert here because FindCommand should guarantee this will not happen
									
									// Make the call
									(*pFunction)(argv);
								}
							}
						}
						commandLine = L"";
					}
					break;

				case '\b':	// Backspace deletes one from line
					if (commandLine.length() != 0) commandLine.resize(commandLine.length() - 1);
					break;

				case 27:	// ESC key
					commandLine = L"";				// clears input line
					break;

				default:	// Add everything else to command line
					commandLine += *iter;
					break;
			}	
		}

		// remove console output that scrolled out of view
		while (display.size() > static_cast<unsigned>(rows)) display.pop_back();
	}

	int Console::TokenizeCommandLine(std::vector<std::wstring>& argv) {
		int argc = 0;
		std::wstring::iterator iter;
		std::wstring arg;
		bool quotes = false;

		for (;;) {

			// Is there anything to work with?
			if(commandLine.empty()) break;

			// Remove leading whitespace
			iter = commandLine.begin();
			while (isspace(*iter)) {
				commandLine.erase(iter);

				if (!commandLine.length()) break; // Nothing but space left
				
				// Next character
				iter = commandLine.begin();
			}

			// Was it actually trailing whitespace?
			if (!commandLine.length()) break;// Nothing left to do

			// We have an argument
			++argc;
			arg.clear();
			// Use space as a delimiter unless inside quotes or brackets (nestable)
			while (!isspace(*iter) || quotes) {
				if (*iter == '"') {
					// Flip the quotes flag
					quotes = !quotes;

				} 

				// Add to argument
				arg += (*iter);

				// Delete the character and move on on
				iter = commandLine.erase(iter);

				// Are we at the end of the string?
				if (iter == commandLine.end()) {

					// Did they close their quotes?
					if (quotes) {
						return -1;
					}
					break;
				}
			}

			// Store the arg
			argv.push_back(arg);
		}

		// Return the number of args found
		return argc;
	}

	bool Console::FindCommand(std::vector<std::wstring>& argv) {

		// Check for partial match
		std::list<std::wstring> possibilities;
		std::list<std::wstring>::iterator liter;

		for(unsigned index = 0; index < (argv[0].size()); ++index) {

			if (index == 0) {
				// Bootstrap the list of possibilities
				CommandMapConstIter citer = commandMap.begin();

				while (citer != commandMap.end()) {
					if (citer->first[index] == argv[0][index]) {
						possibilities.push_back(citer->first);
					}
					++citer;
				}

			} else {
				// Update the list of possiblities

				// A more efficient search here would be nice.
				liter = possibilities.begin();
				while (liter != possibilities.end()) {
					if ((*liter)[index] != argv[0][index]) {
						// Remove this possibility from the list
						liter = possibilities.erase(liter);
					} else {
						// check for exact match
						if (argv[0] == (*liter)) {
							// Exact match, we're done
							argv[0] = (*liter);
							return true;
						}
						++liter;
					}
				}
			}

			if (!possibilities.size()) {
				output << L"No such command: " << argv[0] << std::endl;
				return false;
			} 
		}

		if (possibilities.size() != 1) {
			// Ambiguous
			output << "Ambiguous command, possibilities: ";
			liter = possibilities.begin();
			while (liter != possibilities.end()) {
				output << (*liter) << ' ';
				++liter;
			}
			return false;

		} else {
			// We have a partial match
			argv[0] = (*(possibilities.begin()));
		}
		return true;
	}

	bool Console::Render2D() {
		if (!active) return true;
		
		// Renders the upper portion (output) of the Console
		upper.Render2D();    

		// Renders the lower portion (input) of the Console
		lower.Render2D();    

		// Renders the input line text
		font.Render2D(commandLine, D3DXVECTOR2(2, rows * static_cast<float>(font.GetHeight())));        

		// Render the output text
		float position = 0;
		std::list<std::wstring>::reverse_iterator liter = display.rbegin();
		while (liter != display.rend()) {   
			font.Render2D(*liter, D3DXVECTOR2(2, position), BLACK);                    
			position += font.GetHeight();
			++liter;
		}           
		return true;
	}
	
	void Console::OnResetDevice(const D3DSURFACE_DESC* d) {
		upper.SetScaling(D3DXVECTOR2(static_cast<float>(d->Width), static_cast<float>(font.GetHeight()) * rows));		
		lower.SetScaling(D3DXVECTOR2(static_cast<float>(d->Width), static_cast<float>(font.GetHeight())));
	}

	const Font* Console::GetFont() { return &font; }
	void DXFUpdateConsole() { Console::pConsole->Update(); }
	void DXFRenderConsole() { Console::pConsole->Render2D(); }
	void DXFRegisterCommand(const wchar_t* command, CommandFunction function) { Console::pConsole->RegisterCommand(command, function); }
} // namespace dxf