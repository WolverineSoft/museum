/*	DXFramework Copyright (c) 2005, Jonathan Voigt, University of Michigan.
	See http://dxframework.sourceforge.net/ for a list of contributors.
	All rights reserved.

	Redistribution and use in source and binary forms, with or without modification, 
	are permitted provided that the following conditions are met:

		* Redistributions of source code must retain the above copyright notice, 
		this list of conditions and the following disclaimer.

		* Redistributions in binary form must reproduce the above copyright notice, 
		this list of conditions and the following disclaimer in the documentation 
		and/or other materials provided with the distribution.

		* Neither the name of the DXFramework project nor the names of its 
		contributors may be used to endorse or promote products derived from this 
		software without specific prior written permission.

	THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND 
	ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED 
	WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE 
	DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR 
	ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES 
	(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; 
	LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON 
	ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT 
	(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS 
	SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/

#pragma once

#include "dxframework.h"

namespace dxf {
	/** View class manages the video device and the rendering procedure	*/
	class View {
	public:
		View();

		/** create the device with the suggested width and height, possibly force that
			width and height.  These params are the destination of dxf::Game's params.
		*/
		void Load(int initialWidth, int initialHeight, bool forceResolution);
		/** The name of the application (passed) is used when creating a window */
		HRESULT Init(const wchar_t* windowName);
		void Unload();

		/** Set a rectangle of area on the screen that needs to be cleared each frame.
			This should only be done when necessary, if everything in the background is
			going to get written over, this is not necessary.
		*/
		void SetClearRect(const D3DRECT& clearRect);
		/** Turn clearing on/off */
		void SetClear(bool clearEachFrame);
		/** Set what color to clear the back buffer with when clearing is on. */
		void SetClearColor(D3DCOLOR clearColor);

		// DXUT Callbacks
		bool ModifyDeviceSettings( DXUTDeviceSettings* pDeviceSettings, const D3DCAPS9* pCaps, void* pUserContext );
		HRESULT OnCreateDevice( IDirect3DDevice9* pd3dDevice, const D3DSURFACE_DESC* pBackBufferSurfaceDesc, void* pUserContext );
		HRESULT OnResetDevice( IDirect3DDevice9* pd3dDevice, const D3DSURFACE_DESC* pBackBufferSurfaceDesc, void* pUserContext );
		void OnLostDevice( void* pUserContext );
		void OnDestroyDevice( void* pUserContext );
		void OnFrameRender( IDirect3DDevice9* pd3dDevice, double fTime, float fElapsedTime, void* pUserContext );

		ID3DXSprite* GetD3DXSprite();

		static View* pView;
	protected:
		ID3DXSprite* pd3dxSprite;

		bool clear;
		D3DRECT clearRect;
		D3DCOLOR clearColor;
		int initialWidth;
		int initialHeight;
		bool forceResolution;
	};

	ID3DXSprite* DXFGetD3DXSprite();
	void DXFSetClear(bool clearEachFrame);
	void DXFSetClearColor(D3DCOLOR clearColor);
	void DXFSetClearRect(const D3DRECT& clearRect);
} // namespace dxf