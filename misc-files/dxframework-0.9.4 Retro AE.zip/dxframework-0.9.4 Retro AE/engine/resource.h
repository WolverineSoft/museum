//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by engine.rc
//
#define IDI_ICON1                       101
#define IDC_WINDOWED                    1000
#define IDC_FULLSCREEN                  1001
#define IDC_RES1024X768                 1006
#define IDC_RES800X600                  1014
#define IDC_SWAPDISCARD                 1015
#define IDC_3DYES                       1018
#define IDC_3DNO                        1019
#define IDC_REFRESHRATE                 1020
#define IDC_FMTA8R8G8B8                 1022
#define IDC_FMTR8G8B8                   1023
#define IDC_FMTA4R4G4B4                 1024
#define IDC_FMTX8R8G8B8                 1025
#define IDC_FMTA1R5G5B5                 1026
#define IDC_FMTX1R5G5B5                 1027
#define IDC_FMTR5G6B5                   1028
#define IDC_SWAPFLIP                    1030
#define IDC_RES640x480                  1031
#define IDC_RES1152X864                 1032
#define IDC_PRESIMM                     1035
#define IDC_PRESONE                     1036
#define IDC_ELIGHT                      1037
#define IDC_ESPECULAR                   1038
#define IDC_EDGEAA                      1039
#define IDC_FULLAA                      1040
#define IDC_FLOATEXCEPT                 1041
#define IDC_INDEX16                     1042
#define IDC_INDEX32                     1043

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        107
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1001
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
