/*	DXFramework Copyright (c) 2005, Jonathan Voigt, University of Michigan.
	See http://dxframework.sourceforge.net/ for a list of contributors.
	All rights reserved.

	Redistribution and use in source and binary forms, with or without modification, 
	are permitted provided that the following conditions are met:

		* Redistributions of source code must retain the above copyright notice, 
		this list of conditions and the following disclaimer.

		* Redistributions in binary form must reproduce the above copyright notice, 
		this list of conditions and the following disclaimer in the documentation 
		and/or other materials provided with the distribution.

		* Neither the name of the DXFramework project nor the names of its 
		contributors may be used to endorse or promote products derived from this 
		software without specific prior written permission.

	THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND 
	ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED 
	WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE 
	DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR 
	ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES 
	(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; 
	LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON 
	ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT 
	(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS 
	SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/

#pragma once

#include "dxframework.h"

namespace dxf {

	/** Each font used has metadata stored in this font node structure.
	*/
	struct FontNode {
		ID3DXFont* pFont;	///< pointer to directx font interface
		LONG height;		///< font height
		LONG weight;		///< font weight (bold, etc)
		unsigned count;		///< number of dxf::Font classes referring to this font
		std::wstring name;	///< the name of the font face
	};

	typedef std::vector<FontNode*> FontNodeVector;
	typedef std::vector<FontNode*>::iterator FontNodeVectorIter;

	/** Font class, used for drawing fonts on the screen.
		Use fonts commonly installed with windows, I'm not sure what happens
		if you specify a font not available in windows.
	*/
	class Font {
	public:
		Font();

		/** Load a font of a specific face, height and weight.
			Use popular windows fonts as the name (e.g. "Helvetica").
			Height is basically the font size.
			use the FW_ constants for font weight:
			FW_NORMAL, etc. (right click->go to declaration "wingdi.h").
		*/
		HRESULT Load(const std::wstring& name, LONG height, LONG weight);
		void Unload();

		/** Draw the text to the screen.  Defaults to white text in the upper-left corner of the
			screen.  Use the other parameters to control how it looks.  Scaling allows you to
			temporarily change the size and stretch fonts in weird ways but try to make the 
			common case 1:1.
		*/
		void Render2D(const std::wstring& text, D3DXVECTOR2 position = D3DXVECTOR2(0,0), 
			D3DCOLOR color = WHITE, D3DXVECTOR2 scaling = D3DXVECTOR2(1,1), bool center = false) const;

		LONG GetHeight() const;
		LONG GetWeight() const;

		void GetTextExtent(const std::wstring& text, SIZE& size) const;

		static HRESULT OnCreateDevice();
		static HRESULT OnResetDevice();
		static void OnLostDevice();
		static void OnDestroyDevice();

	private:
		static FontNodeVector fonts;	///< vector of all fonts ever created
		FontNode* pFontNode;
	};

} // namespace dxf