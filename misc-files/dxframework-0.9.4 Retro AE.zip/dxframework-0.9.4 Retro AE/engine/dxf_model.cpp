/*	DXFramework Copyright (c) 2005, Jonathan Voigt, University of Michigan.
	See http://dxframework.sourceforge.net/ for a list of contributors.
	All rights reserved.

	Redistribution and use in source and binary forms, with or without modification, 
	are permitted provided that the following conditions are met:

		* Redistributions of source code must retain the above copyright notice, 
		this list of conditions and the following disclaimer.

		* Redistributions in binary form must reproduce the above copyright notice, 
		this list of conditions and the following disclaimer in the documentation 
		and/or other materials provided with the distribution.

		* Neither the name of the DXFramework project nor the names of its 
		contributors may be used to endorse or promote products derived from this 
		software without specific prior written permission.

	THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND 
	ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED 
	WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE 
	DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR 
	ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES 
	(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; 
	LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON 
	ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT 
	(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS 
	SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/

#include "dxf_model.h"
#include "dxf_gamestate.h"
#include "dxf_console.h"
#include "dxf_controller.h"

void CALLBACK OnFrameMove( IDirect3DDevice9* pd3dDevice, double fTime, float fElapsedTime, void* pUserContext ) {
	return dxf::Model::pModel->OnFrameMove(pd3dDevice, fTime, fElapsedTime, pUserContext);
}

namespace dxf {
	extern bool gFPS;

	Model* Model::pModel = 0;

	Model::Model() {
		assert(!pModel);
	}

	void Model::Load() {
		assert(!pModel);
		pModel = this;

		StateManager::Load();

		DXUTSetCallbackFrameMove( ::OnFrameMove );
	}

	void Model::Unload() {
		assert(pModel);
		pModel = 0;

		StateManager::Unload();
	}

	void Model::OnFrameMove( IDirect3DDevice9* pd3dDevice, double fTime, float fElapsedTime, void* pUserContext ) {
		DXFPollInput();
		DXFUpdateConsole();
		if (pCurrent) pCurrent->Update(fTime, fElapsedTime);
		StateManager::Update();
	}


	void Model::RenderPre2D(double fTime, float fElapsedTime) {
		if (pCurrent) pCurrent->RenderPre2D(fTime, fElapsedTime);
	}

	void Model::Render3D(double fTime, float fElapsedTime) {
		if (pCurrent) pCurrent->Render3D(fTime, fElapsedTime);
	}

	void Model::Render2D(double fTime, float fElapsedTime) {
		if (pCurrent) pCurrent->Render2D(fTime, fElapsedTime);
		if (gFPS) Console::pConsole->GetFont()->Render2D(DXUTGetFrameStats());
	}

	GUI* DXFGetGUI() { return Model::pModel->GetGUI(); }
	GameState* GetCurrentGameState() { return Model::pModel->GetCurrentGameState(); }
	void DXFRenderPre2D(double fTime, float fElapsedTime) { Model::pModel->RenderPre2D(fTime, fElapsedTime); }
	void DXFRender3D(double fTime, float fElapsedTime) { Model::pModel->Render3D(fTime, fElapsedTime); }
	void DXFRender2D(double fTime, float fElapsedTime) { Model::pModel->Render2D(fTime, fElapsedTime); }
	void DXFChangeState(const std::wstring& name) { Model::pModel->ChangeState(name); }
	void DXFRegisterState(const std::wstring& name, GameState* pState) { Model::pModel->RegisterState(name, pState); }
} // namespace dxf