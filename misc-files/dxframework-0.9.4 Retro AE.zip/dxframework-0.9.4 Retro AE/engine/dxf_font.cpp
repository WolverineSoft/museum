/*	DXFramework Copyright (c) 2005, Jonathan Voigt, University of Michigan.
	See http://dxframework.sourceforge.net/ for a list of contributors.
	All rights reserved.

	Redistribution and use in source and binary forms, with or without modification, 
	are permitted provided that the following conditions are met:

		* Redistributions of source code must retain the above copyright notice, 
		this list of conditions and the following disclaimer.

		* Redistributions in binary form must reproduce the above copyright notice, 
		this list of conditions and the following disclaimer in the documentation 
		and/or other materials provided with the distribution.

		* Neither the name of the DXFramework project nor the names of its 
		contributors may be used to endorse or promote products derived from this 
		software without specific prior written permission.

	THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND 
	ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED 
	WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE 
	DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR 
	ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES 
	(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; 
	LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON 
	ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT 
	(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS 
	SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/

#include "dxf_font.h"
#include "dxf_view.h"
#include "dxf_game.h"

namespace dxf {
	std::vector<FontNode*> Font::fonts;

	Font::Font() {
		pFontNode = 0;
	}

	HRESULT Font::Load(const std::wstring& name, LONG height, LONG weight) {
		assert (!pFontNode);

		HRESULT hr;

		FontNodeVectorIter iter = fonts.begin();
		while(iter != fonts.end()) {
			if (((*iter)->name == name) && ((*iter)->height == height) && ((*iter)->weight == weight)) {
				pFontNode = *iter;
				++(pFontNode->count);
				return S_OK;
			}
			++iter;
		}
		
		pFontNode = new FontNode;
		if (!pFontNode) return E_OUTOFMEMORY;
		fonts.push_back(pFontNode);

		pFontNode->name = name;
		pFontNode->height = height;
		pFontNode->weight = weight;
		pFontNode->count = 1;

		V_RETURN(D3DXCreateFont(DXUTGetD3DDevice(), height, 0, weight, 0, FALSE, 
			DEFAULT_CHARSET, OUT_DEFAULT_PRECIS, DEFAULT_QUALITY, 
			DEFAULT_PITCH | FF_DONTCARE, name.c_str(), &pFontNode->pFont));

		return S_OK;
	}

	void Font::Unload() {
		assert(pFontNode);

		--(pFontNode->count);

		if (!pFontNode->count) {
			FontNodeVectorIter iter = fonts.begin();
			while(iter != fonts.end()) {
				if ((*iter) == pFontNode) {
					fonts.erase(iter);
					break;
				}
				++iter;
			}
			SAFE_RELEASE(pFontNode->pFont);
			SAFE_DELETE(pFontNode);
		}
	}

	void Font::Render2D(const std::wstring& text, D3DXVECTOR2 position, D3DCOLOR color, D3DXVECTOR2 scaling, bool center) const {

		D3DXMATRIX ident;
		D3DXVECTOR2 scaleCenter(0, static_cast<float>(GetHeight()) / 2);
		D3DXMatrixTransformation2D(&ident, &scaleCenter, 0, &scaling, 0, 0, &position);

		DXFGetD3DXSprite()->SetTransform(&ident);

		RECT font_rect;
		SetRect(&font_rect, 0, 0, 0, 0);

		HRESULT hr;
		DWORD flags = DT_NOCLIP;
		flags |= center ? DT_CENTER : 0;
		V(pFontNode->pFont->DrawText(DXFGetD3DXSprite(), text.c_str(), text.length(), &font_rect, flags, color));
	}

	LONG Font::GetHeight() const {
		return pFontNode->height;
	}

	LONG Font::GetWeight() const {
		return pFontNode->weight;
	}

	HRESULT Font::OnCreateDevice() {
		HRESULT hr;
		
		FontNodeVectorIter iter = fonts.begin();
		while(iter != fonts.end()) {
			V_RETURN(D3DXCreateFont(DXUTGetD3DDevice(), (*iter)->height, 0, (*iter)->weight, 0, FALSE, 
					DEFAULT_CHARSET, OUT_DEFAULT_PRECIS, DEFAULT_QUALITY, 
					DEFAULT_PITCH | FF_DONTCARE, (*iter)->name.c_str(), &(*iter)->pFont));
			++iter;
		}

		return S_OK;
	}

	HRESULT Font::OnResetDevice() {
		HRESULT hr;

		FontNodeVectorIter iter = fonts.begin();
		while(iter != fonts.end()) {
			V_RETURN((*iter)->pFont->OnResetDevice());
			++iter;
		}

		return S_OK;
	}

	void Font::OnLostDevice() {
		FontNodeVectorIter iter = fonts.begin();
		while(iter != fonts.end()) {
			if ((*iter)->pFont) (*iter)->pFont->OnLostDevice();
			++iter;
		}
	}

	void Font::OnDestroyDevice() {
		FontNodeVectorIter iter = fonts.begin();
		while(iter != fonts.end()) {
			SAFE_RELEASE((*iter)->pFont);
			++iter;
		}
	}

	void Font::GetTextExtent(const std::wstring& text, SIZE& size) const {
		D3DXMATRIX ident;
		D3DXVECTOR2 scaleCenter(0, static_cast<float>(GetHeight()) / 2);
		D3DXVECTOR2 scaling = D3DXVECTOR2(1, 1);
		D3DXVECTOR2 position = D3DXVECTOR2(0, 0);

		D3DXMatrixTransformation2D(&ident, &scaleCenter, 0, &scaling, 0, 0, &position);

		DXFGetD3DXSprite()->SetTransform(&ident);

		RECT font_rect;
		SetRect(&font_rect, 0, 0, 0, 0);

		HRESULT hr;
		V(pFontNode->pFont->DrawText(0, text.c_str(), text.length(), &font_rect, DT_NOCLIP | DT_CALCRECT, 0));

		size.cx = font_rect.right-font_rect.left;
		size.cy = font_rect.bottom-font_rect.top;
	}
} // namespace dxf