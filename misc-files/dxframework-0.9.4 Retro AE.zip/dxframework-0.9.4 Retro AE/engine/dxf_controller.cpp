/*	DXFramework Copyright (c) 2005, Jonathan Voigt, University of Michigan.
	See http://dxframework.sourceforge.net/ for a list of contributors.
	All rights reserved.

	Redistribution and use in source and binary forms, with or without modification, 
	are permitted provided that the following conditions are met:

		* Redistributions of source code must retain the above copyright notice, 
		this list of conditions and the following disclaimer.

		* Redistributions in binary form must reproduce the above copyright notice, 
		this list of conditions and the following disclaimer in the documentation 
		and/or other materials provided with the distribution.

		* Neither the name of the DXFramework project nor the names of its 
		contributors may be used to endorse or promote products derived from this 
		software without specific prior written permission.

	THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND 
	ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED 
	WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE 
	DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR 
	ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES 
	(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; 
	LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON 
	ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT 
	(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS 
	SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/

#include "dxf_controller.h"
#include "dxf_console.h"

LPDIRECTINPUT8       g_pDI = 0;         
LPDIRECTINPUTDEVICE8 g_pJoystick = 0;     
dxf::JoystickCaps g_JoystickCaps;

BOOL CALLBACK EnumJoysticksCallback( const DIDEVICEINSTANCE* pdidInstance, VOID* pContext ){
    HRESULT hr;

    // Obtain an interface to the enumerated Joystick.
    hr = g_pDI->CreateDevice( pdidInstance->guidInstance, &g_pJoystick, NULL );

    // If it failed, then we can't use this Joystick. (Maybe the user unplugged
    // it while we were in the middle of enumerating it.)
    if( FAILED(hr) ) return DIENUM_CONTINUE;

    // Stop enumeration. Note: we're just taking the first Joystick we get. You
    // could store all the enumerated Joysticks and let the user pick.
    return DIENUM_STOP;
}

BOOL CALLBACK EnumObjectsCallback( const DIDEVICEOBJECTINSTANCE* pdidoi,
                                   VOID* pContext )
{
	HRESULT hr;

    static int nSliderCount = 0;  // Number of returned slider controls
    static int nPOVCount = 0;     // Number of returned POV controls

    // For axes that are returned, set the DIPROP_RANGE property for the
    // enumerated axis in order to scale min/max values.
    if( pdidoi->dwType & DIDFT_AXIS )
    {
        DIPROPRANGE diprg; 
        diprg.diph.dwSize       = sizeof(DIPROPRANGE); 
        diprg.diph.dwHeaderSize = sizeof(DIPROPHEADER); 
        diprg.diph.dwHow        = DIPH_BYID; 
        diprg.diph.dwObj        = pdidoi->dwType; // Specify the enumerated axis
        diprg.lMin              = -1000; 
        diprg.lMax              = +1000; 
    
        // Set the range for the axis
		V(g_pJoystick->SetProperty( DIPROP_RANGE, &diprg.diph));
		if (FAILED(hr)) return DIENUM_STOP;         
    }

    // Set the UI to reflect what objects the Joystick supports
    if (pdidoi->guidType == GUID_XAxis) {
		g_JoystickCaps.x = true;
    }
    if (pdidoi->guidType == GUID_YAxis) {
		g_JoystickCaps.y = true;
    }
    if (pdidoi->guidType == GUID_ZAxis) {
		g_JoystickCaps.z = true;
    }
    if (pdidoi->guidType == GUID_RxAxis) {
		g_JoystickCaps.xr = true;
    }
    if (pdidoi->guidType == GUID_RyAxis) {
 		g_JoystickCaps.yr = true;
    }
    if (pdidoi->guidType == GUID_RzAxis) {
		g_JoystickCaps.zr = true;
    }
    if (pdidoi->guidType == GUID_Slider) {
		++g_JoystickCaps.sliderCount;
    }
    if (pdidoi->guidType == GUID_POV) {
		++g_JoystickCaps.povCount;
    }

    return DIENUM_CONTINUE;
}

void CALLBACK KeyboardProc( UINT nChar, bool bKeyDown, bool bAltDown, void* pUserContext ) {
	dxf::Controller::pController->KeyboardProc(nChar, bKeyDown, bAltDown, pUserContext);
}

void CALLBACK MouseProc( bool bLeftButtonDown, bool bRightButtonDown, bool bMiddleButtonDown, bool bSideButton1Down, bool bSideButton2Down, INT nMouseWheelDelta, INT xPos, INT yPos, void* pUserContext ) {
	dxf::Controller::pController->MouseProc(bLeftButtonDown, bRightButtonDown, bMiddleButtonDown, bSideButton1Down, bSideButton2Down, nMouseWheelDelta, xPos, yPos, pUserContext);
}

namespace dxf {
	extern bool gMouse;

	Controller* Controller::pController = 0;

	Controller::Controller() {
		assert(!pController);
		ZeroMemory(&g_JoystickCaps, sizeof(JoystickCaps));
	}

	HRESULT Controller::Load() {
		assert(!pController);
		pController = this;

		current = 0;

		keyboardRaw.reset();
		keyboard[0].reset();
		keyboard[1].reset();

		mouseRaw.reset();
		mouse[0].reset();
		mouse[1].reset();

		ZeroMemory(&jsRaw, sizeof(DIJOYSTATE2));
		ZeroMemory(&js, sizeof(DIJOYSTATE2) * 2);

		DXUTSetCallbackKeyboard( ::KeyboardProc );
		DXUTSetCallbackMouse( ::MouseProc );

		HRESULT hr;
		V_RETURN(DirectInput8Create(GetModuleHandle(0), DIRECTINPUT_VERSION, IID_IDirectInput8, (VOID**)&g_pDI, 0));

		V_RETURN(g_pDI->EnumDevices(DI8DEVCLASS_GAMECTRL, EnumJoysticksCallback, 0, DIEDFL_ATTACHEDONLY));

		if(!g_pJoystick) {
			g_JoystickCaps.enabled = false;
			Console::output << L"Joystick not found." << std::endl;
			return S_OK;
		}

		g_JoystickCaps.enabled = true;
		Console::output << L"Joystick found." << std::endl;

		V_RETURN(g_pJoystick->SetDataFormat(&c_dfDIJoystick2));

		HWND h = DXUTGetHWND();
		V_RETURN(g_pJoystick->SetCooperativeLevel(h, DISCL_EXCLUSIVE | DISCL_FOREGROUND));

		V_RETURN(g_pJoystick->EnumObjects(EnumObjectsCallback, (VOID*)DXUTGetHWND(), DIDFT_ALL));

		return S_OK;
	}

	void Controller::Unload() {
		assert(pController);
		pController = 0;
	}

	void Controller::KeyboardProc( UINT nChar, bool bKeyDown, bool bAltDown, void* pUserContext ) {
		keyboardRaw.set(static_cast<BYTE>(nChar), bKeyDown);
	}

	void Controller::MouseProc( bool bLeftButtonDown, bool bRightButtonDown, bool bMiddleButtonDown, bool bSideButton1Down, 
									bool bSideButton2Down, INT nMouseWheelDelta, INT xPos, INT yPos, void* pUserContext ) {
		mouseRaw.set(MBUTTON_LEFT, bLeftButtonDown);
		mouseRaw.set(MBUTTON_RIGHT, bRightButtonDown);
		mouseRaw.set(MBUTTON_MIDDLE, bMiddleButtonDown);
		mouseRaw.set(MBUTTON_SIDE1, bSideButton1Down);
		mouseRaw.set(MBUTTON_SIDE2, bSideButton2Down);
		mouseWheelDelta = nMouseWheelDelta;
	}

	void Controller::Poll() {
		if (current) {
			current = 0;
		} else {
			current = 1;
		}

		keyboard[current] = keyboardRaw;
		mouse[current] = mouseRaw;

		if (!g_pJoystick) return;

		HRESULT hr;
		// Poll the device to read the current state
		hr = g_pJoystick->Poll(); 
		if(FAILED(hr)) {
			// DInput is telling us that the input stream has been
			// interrupted. We aren't tracking any state between polls, so
			// we don't have any special reset that needs to be done. We
			// just re-acquire and try again.
			hr = g_pJoystick->Acquire();
			while( hr == DIERR_INPUTLOST ) {
				hr = g_pJoystick->Acquire();
			}

			// hr may be DIERR_OTHERAPPHASPRIO or other errors.  This
			// may occur when the app is minimized or in the process of 
			// switching, so just try again later 
			int last;
			if (current) {
				last = 0;
			} else {
				last = 1;
			}
			CopyMemory(&js[current], &js[last], sizeof(DIJOYSTATE2));
			return; 
		}

		// Get the input's device state
		V(g_pJoystick->GetDeviceState(sizeof(DIJOYSTATE2), &jsRaw));

		// Update recorded state
		CopyMemory(&js[current], &jsRaw, sizeof(DIJOYSTATE2));
	}

	eButtonState Controller::CheckKeyboard(BYTE key) {
		int last;
		if (current) {
			last = 0;
		} else {
			last = 1;
		}

		if (!keyboard[current].test(key) && keyboard[last].test(key)) {
			return BUTTON_RELEASED;     

		} else if (keyboard[current].test(key) && !keyboard[last].test(key)) {
			return BUTTON_PRESSED;

		} else if (keyboard[current].test(key)) {
			return BUTTON_DOWN;
		}         
		return BUTTON_UP;        
	}

	void Controller::BufferedInput(wchar_t key) {
		bufferedInput += key;
	}

	void Controller::GetBufferedInput(std::wstring& input) {
		input = bufferedInput;
		bufferedInput = L"";
	}

	eButtonState Controller::CheckMouse(eMouseButton button) {
		int last;
		if (current) {
			last = 0;
		} else {
			last = 1;
		}

		if (!mouse[current].test(button) && mouse[last].test(button)) {
			return BUTTON_RELEASED;     

		} else if (mouse[current].test(button) && !mouse[last].test(button)) {
			return BUTTON_PRESSED;

		} else if (mouse[current].test(button)) {
			return BUTTON_DOWN;
		}         
		return BUTTON_UP;        
	}

	int Controller::GetMouseWheelDelta() { return mouseWheelDelta; }

	void Controller::SetMousePosition(int x, int y) {
		mousePos.x = x;
		mousePos.y = y;
		if (gMouse) Console::output << "(" << mousePos.x << "," << mousePos.y << ")" << std::endl;
	}

	POINT Controller::GetMousePosition() {
		return mousePos;
	}

	eButtonState Controller::CheckJoystick(int button) {
		if ((button < 0) || (button >= 128)) return BUTTON_UP;

		int last;
		if (current) {
			last = 0;
		} else {
			last = 1;
		}

		if (!js[current].rgbButtons[button] && js[last].rgbButtons[button]) {
			return BUTTON_RELEASED;     

		} else if (js[current].rgbButtons[button] && !js[last].rgbButtons[button]) {
			return BUTTON_PRESSED;

		} else if (js[current].rgbButtons[button]) {
			return BUTTON_DOWN;
		}         
		return BUTTON_UP;        
	}

	const DIJOYSTATE2* Controller::GetJoystickState() {
		return &jsRaw;
	}

	void DXFPollInput() { Controller::pController->Poll(); }
	eButtonState DXFCheckKeyboard(BYTE key) { return Controller::pController->CheckKeyboard(key); }
	void DXFGetBufferedInput(std::wstring& input) { Controller::pController->GetBufferedInput(input); }
	eButtonState DXFCheckMouse(eMouseButton button) { return Controller::pController->CheckMouse(button); }
	int DXFGetMouseWheelDelta() { return Controller::pController->GetMouseWheelDelta(); }
	POINT DXFGetMousePosition() { return Controller::pController->GetMousePosition(); }
	const JoystickCaps* DXFGetJoystickCapabilities() { return &g_JoystickCaps; }
	eButtonState DXFCheckJoystick(int button) { return Controller::pController->CheckJoystick(button); }
	const DIJOYSTATE2* DXFGetJoystickState() { return Controller::pController->GetJoystickState(); }
} // namespace dxf