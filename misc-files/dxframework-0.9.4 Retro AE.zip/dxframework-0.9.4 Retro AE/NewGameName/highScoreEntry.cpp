#include "HighScoreEntry.h"
#include "dxf_view.h"
#include "dxf_controller.h"
#include "dxf_game.h"

#include "registrar.h"

#include "highscoretable.h"
#include <sstream>
#include <iomanip>

using namespace dxf;
using std::vector;
using std::string;
using std::ostringstream;

#define IDC_A 1
#define IDC_B 2
#define IDC_C 3
#define IDC_D 4
#define IDC_E 5
#define IDC_F 6
#define IDC_G 7
#define IDC_H 8
#define IDC_I 9
#define IDC_J 10
#define IDC_K 11
#define IDC_L 12
#define IDC_M 13
#define IDC_N 14
#define IDC_O 15
#define IDC_P 16
#define IDC_Q 17
#define IDC_R 18
#define IDC_S 19
#define IDC_T 20
#define IDC_U 21
#define IDC_V 22
#define IDC_W 23
#define IDC_X 24
#define IDC_Y 25
#define IDC_Z 26
#define IDC_BACKSPACE 27
#define IDC_SPACE 28
#define IDC_DONE 29

char hsName[4];
int currentLetter;
int firstSpot = 100;
int secondSpot = 125;
int thirdSpot = 150;
int fourthSpot = 175;
int fifthSpot = 200;

void CALLBACK OnHSEGUIEvent( UINT nEvent, int nControlID, CDXUTControl* pControl, void* pUserContext ) {
	HighScoreEntry::pHighScoreEntry->OnGUIEvent(nEvent, nControlID, pControl, pUserContext);
}

HighScoreEntry* HighScoreEntry::pHighScoreEntry = 0;

void HighScoreEntry::OnGUIEvent( UINT nEvent, int nControlID, CDXUTControl* pControl, void* pUserContext ) {
	
	if (nControlID <= IDC_Z && nControlID >= IDC_A) {
		if (currentLetter < 3) {
			hsName[currentLetter] = static_cast<char>(nControlID + 'A' - 1);
			currentLetter++;
		}
	}
	else if (nControlID == IDC_BACKSPACE) {
		if (currentLetter > 0) {
			currentLetter--;
			hsName[currentLetter] = '_';
		}
	}
	else if (nControlID == IDC_SPACE) {
		if (currentLetter < 3) {
			hsName[currentLetter] = '_';
			currentLetter++;
		}
	}
	else if (nControlID == IDC_DONE) {
		HighScoreTable hst(SCORE_FILE);
		hst.add_score(hsName,score,level);
		hst.save_to_file(SCORE_FILE);
		DXFChangeState(Registrar::kHighScores);
	}
	else {
		assert(false);
	}
}

HighScoreEntry::HighScoreEntry() {
	assert(!pHighScoreEntry);
	pHighScoreEntry = this;
	dialog.Init(&drm);
	hsName[0] = '_';
	hsName[1] = '_';
	hsName[2] = '_';
	hsName[3] = '\0';
}

HRESULT HighScoreEntry::Load() {
	HRESULT(hr);

	V_RETURN(font.Load(L"Helvitica", 36, FW_NORMAL));

	//V_RETURN(background.CreateFromFile(L"Art/HighScoreEntryBackground.png"));      
	V_RETURN(dialog.AddButton(IDC_A, L"A", firstSpot, 325, 25, 25, 'A'));
	V_RETURN(dialog.AddButton(IDC_B, L"B", secondSpot, 325, 25, 25, 'B'));
	V_RETURN(dialog.AddButton(IDC_C, L"C", thirdSpot, 325, 25, 25, 'C'));
	V_RETURN(dialog.AddButton(IDC_D, L"D", fourthSpot, 325, 25, 25, 'D'));
	V_RETURN(dialog.AddButton(IDC_E, L"E", fifthSpot, 325, 25, 25, 'E'));
	V_RETURN(dialog.AddButton(IDC_F, L"F", firstSpot, 350, 25, 25, 'F'));
	V_RETURN(dialog.AddButton(IDC_G, L"G", secondSpot, 350, 25, 25, 'G'));
	V_RETURN(dialog.AddButton(IDC_H, L"H", thirdSpot, 350, 25, 25, 'H'));
	V_RETURN(dialog.AddButton(IDC_I, L"I", fourthSpot, 350, 25, 25, 'I'));
	V_RETURN(dialog.AddButton(IDC_J, L"J", fifthSpot, 350, 25, 25, 'J'));
	V_RETURN(dialog.AddButton(IDC_K, L"K", firstSpot, 375, 25, 25, 'K'));
	V_RETURN(dialog.AddButton(IDC_L, L"L", secondSpot, 375, 25, 25, 'L'));
	V_RETURN(dialog.AddButton(IDC_M, L"M", thirdSpot, 375, 25, 25, 'M'));
	V_RETURN(dialog.AddButton(IDC_N, L"N", fourthSpot, 375, 25, 25, 'N'));
	V_RETURN(dialog.AddButton(IDC_O, L"O", fifthSpot, 375, 25, 25, 'O'));
	V_RETURN(dialog.AddButton(IDC_P, L"P", firstSpot, 400, 25, 25, 'P'));
	V_RETURN(dialog.AddButton(IDC_Q, L"Q", secondSpot, 400, 25, 25, 'Q'));
	V_RETURN(dialog.AddButton(IDC_R, L"R", thirdSpot, 400, 25, 25, 'R'));
	V_RETURN(dialog.AddButton(IDC_S, L"S", fourthSpot, 400, 25, 25, 'S'));
	V_RETURN(dialog.AddButton(IDC_T, L"T", fifthSpot, 400, 25, 25, 'T'));
	V_RETURN(dialog.AddButton(IDC_U, L"U", firstSpot, 425, 25, 25, 'U'));
	V_RETURN(dialog.AddButton(IDC_V, L"V", secondSpot, 425, 25, 25, 'V'));
	V_RETURN(dialog.AddButton(IDC_W, L"W", thirdSpot, 425, 25, 25, 'W'));
	V_RETURN(dialog.AddButton(IDC_X, L"X", fourthSpot, 425, 25, 25, 'X'));
	V_RETURN(dialog.AddButton(IDC_Y, L"Y", fifthSpot, 425, 25, 25, 'Y'));
	V_RETURN(dialog.AddButton(IDC_Z, L"Z", firstSpot, 450, 25, 25, 'Z'));
	V_RETURN(dialog.AddButton(IDC_SPACE, L"SPACE", secondSpot, 450, 100, 25, 'Q'));
	V_RETURN(dialog.AddButton(IDC_BACKSPACE, L"BACKSPACE", firstSpot, 475, 125, 25, 'Q'));
	V_RETURN(dialog.AddButton(IDC_DONE, L"DONE", firstSpot, 500, 125, 25, 'Q'));

	currentLetter = 0;
	pGUI = this;
	dialog.SetCallback(::OnHSEGUIEvent);

	const D3DSURFACE_DESC* d = DXUTGetBackBufferSurfaceDesc();

	DXFSetClear(true);
	return S_OK;
}

void HighScoreEntry::Unload() {
	dialog.RemoveAllControls();
	drm.UnregisterDialog(&dialog);
	//background.Unload();
}

void HighScoreEntry::Update(double fTime, float fElapsedTime) {
}

void HighScoreEntry::Render2D(double fTime, float fElapsedTime) {
	background.Render2D(D3DXVECTOR2(0, 0));
	font.Render2D(to_wstring(std::string::string(&hsName[0])), D3DXVECTOR2(secondSpot, 250));
	font.Render2D(towstring(score), D3DXVECTOR2(220, 100));
}

void HighScoreEntry::Resize(const D3DSURFACE_DESC* d) {
}


bool HighScoreEntry::MsgProc( HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam) {
	if (drm.MsgProc( hWnd, uMsg, wParam, lParam )) return true;
	if (dialog.MsgProc( hWnd, uMsg, wParam, lParam )) return true;

	// If you do not want escape to quit the program, uncomment this:
	if (uMsg == WM_KEYDOWN && wParam == VK_ESCAPE) {
		// Do something useful with escape
		// Let the engine know we've processed the escape message
		return true;
	}		

	return false;
}

HRESULT HighScoreEntry::OnResetDevice( IDirect3DDevice9* pd3dDevice, const D3DSURFACE_DESC* d) {
	HRESULT hr;
    V_RETURN(GUI::OnResetDevice(pd3dDevice, d));
	dialog.SetLocation( 0, 0 );
	dialog.SetSize( d->Width, d->Height );
	return S_OK;
}

HRESULT HighScoreEntry::OnFrameRender(float fElapsedTime) {
	HRESULT hr;
	V_RETURN(dialog.OnRender(fElapsedTime));
	return S_OK;
}


