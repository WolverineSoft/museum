#include "stringtowstring.h"
#include <windows.h>

using std::wstring;
using std::string;

wstring to_wstring(const string & str)
{
	wchar_t * temp = new wchar_t[str.size() + 1];
	MultiByteToWideChar(CP_UTF8, 0, str.c_str(), -1, temp, str.size() + 1);

	wstring ret(temp);
	delete [] temp;
	return ret;
}

string to_string(const wstring & wstr)
{
	char * temp = new char[wstr.size() + 1];
	WideCharToMultiByte(CP_UTF8, 0, wstr.c_str(), -1, temp, wstr.size() + 1,
			    NULL, NULL);
	string ret(temp);
	delete [] temp;
	return ret;
}
