#ifndef _CONTROLLER_H_
#define _CONTROLLER_H_

#include "dxf.h"
#include <XInput.h>

namespace x360 { //so it doesn't conflict with the dxf::Controller class
	/** Buttons go through four states:
		up --> pressed --> down --> released
	*/
	enum eButtonState {
		BUTTON_UP,			///< button is up now and was up last frame
		BUTTON_PRESSED,		///< button is down now and was up last frame
		BUTTON_DOWN,		///< button is down now and was down last frame
		BUTTON_RELEASED,	///< button is up now and was down last frame
	};	

	enum eControllerButton {
		X360_DPAD_UP,
		X360_DPAD_DOWN,
		X360_DPAD_LEFT,
		X360_DPAD_RIGHT,
		X360_START, 
		X360_BACK, 
		X360_LEFT_CLICK,
		X360_RIGHT_CLICK,
		X360_LEFT_BUMPER, 
		X360_RIGHT_BUMPER,
		X360_RING_OF_LIGHT_PRESS, //dummy
		X360_RING_OF_LIGHT_HOLD, //dummy
		X360_A, 
		X360_B, 
		X360_X,
		X360_Y
	};
	
	class Controller {

	public:
		Controller();

		void Load(int new_controller_number); //init stuff here
		void Unload();

		bool Update(); //must be called each frame
		
		eButtonState CheckButton(eControllerButton in_button);
	
		float CheckLeftStickX(); //returns -1.0 to 1.0
		float CheckLeftStickY();
		float CheckRightStickX();
		float CheckRightStickY();

		float CheckLeftTrigger(); //returns 0.0 to 1.0
		float CheckRightTrigger();

		int getControllerNumber();

		float getLeftVibration();	//returns 0.0 to 1.0
		float getRightVibration();
		bool setVibration(float new_percentage_left, float new_percentage_right);
		

	private:
		XINPUT_STATE state;

		eButtonState button_state[16];

		int controller_number;

		XINPUT_VIBRATION vibration;

	};	

} // namespace x360

#endif
