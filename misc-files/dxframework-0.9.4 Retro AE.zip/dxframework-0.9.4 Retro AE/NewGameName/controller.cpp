#include "controller.h"

using namespace x360;

//This info may be useful.
	///* Note that you may define your own dead zones for the sticks and triggers 
	//(anywhere from 0-65534), or you may use the provided deadzones defined as
	//XINPUT_GAMEPAD_LEFT_THUMB_DEADZONE, XINPUT_GAMEPAD_RIGHT_THUMB_DEADZONE,
	//and XINPUT_GAMEPAD_TRIGGER_THRESHOLD in XInput.h. */

	////Sample vibration code
	////XINPUT_VIBRATION vibration;
	////ZeroMemory( &vibration, sizeof(XINPUT_VIBRATION) );
	////vibration.wLeftMotorSpeed = 32000; // use any value between 0-65535 here
	////vibration.wRightMotorSpeed = 16000; // use any value between 0-65535 here
	////XInputSetState( 0, &vibration );

	///* Note that the right motor is the high-frequency motor, the left motor is
	//the low-frequency motor. They do not always need to be set to the same amount,
	//as they provide different effects. */

	///* Describes the current state of the Xbox 360 Controller. 
	//typedef struct _XINPUT_GAMEPAD {
	//	WORD wButtons;
	//	BYTE bLeftTrigger;
	//	BYTE bRightTrigger;
	//	SHORT sThumbLX;
	//	SHORT sThumbLY;
	//	SHORT sThumbRX;
	//	SHORT sThumbRY;
	//} XINPUT_GAMEPAD, *PXINPUT_GAMEPAD;
	//Members
	//wButtons
	//Bitmask of the device digital buttons, as follows. A set bit indicates that the corresponding button is pressed. 
	//#define XINPUT_GAMEPAD_DPAD_UP          0x00000001
	//#define XINPUT_GAMEPAD_DPAD_DOWN        0x00000002
	//#define XINPUT_GAMEPAD_DPAD_LEFT        0x00000004
	//#define XINPUT_GAMEPAD_DPAD_RIGHT       0x00000008
	//#define XINPUT_GAMEPAD_START            0x00000010
	//#define XINPUT_GAMEPAD_BACK             0x00000020
	//#define XINPUT_GAMEPAD_LEFT_THUMB       0x00000040
	//#define XINPUT_GAMEPAD_RIGHT_THUMB      0x00000080
	//#define XINPUT_GAMEPAD_LEFT_SHOULDER    0x0100
	//#define XINPUT_GAMEPAD_RIGHT_SHOULDER   0x0200
	//#define XINPUT_GAMEPAD_A                0x1000
	//#define XINPUT_GAMEPAD_B                0x2000
	//#define XINPUT_GAMEPAD_X                0x4000
	//#define XINPUT_GAMEPAD_Y                0x8000
	//Bits that are set but not defined above are reserved, and their state is undefined.

	//bLeftTrigger
	//The current value of the left trigger analog control. The value is between 0 and 255.
	//bRightTrigger
	//The current value of the right trigger analog control. The value is between 0 and 255.
	//sThumbLX
	//Left thumbstick x-axis value. Each of the thumbstick axis members is a signed value between -32768 and 32767 describing the position of the thumbstick. A value of 0 is centered. Negative values signify down or to the left. Positive values signify up or to the right. The constants XINPUT_GAMEPAD_LEFT_THUMB_DEADZONE or XINPUT_GAMEPAD_RIGHT_THUMB_DEADZONE can be used as a positive and negative value to filter a thumbstick input.
	//sThumbLY
	//Left thumbstick y-axis value. The value is between -32768 and 32767.
	//sThumbRX
	//Right thumbstick x-axis value. The value is between -32768 and 32767.
	//sThumbRY
	//Right thumbstick y-axis value. The value is between -32768 and 32767.
	//*/
	//

x360::Controller::Controller()
{

}

void x360::Controller::Load(int new_controller_number)
{
	 //Init button states
	for (int i = 0; i < 16; i++)
	{
		button_state[i] = BUTTON_UP;
	}
	
	//Init controller number
	controller_number = new_controller_number;

	//Init vibration
	ZeroMemory( &vibration, sizeof(XINPUT_VIBRATION) );
	vibration.wLeftMotorSpeed = 0; // use any value between 0-65535 here
	vibration.wRightMotorSpeed = 0; // use any value between 0-65535 here
	XInputSetState( controller_number, &vibration );
}

void x360::Controller::Unload()
{

}

bool x360::Controller::Update()
{
	//must be called each frame
	DWORD dwResult;
	ZeroMemory( &state, sizeof(XINPUT_STATE) );

    // Simply get the state of the controller from XInput.
    dwResult = XInputGetState( controller_number, &state );

	if( dwResult != ERROR_SUCCESS )
	{ 
		// Controller is not connected
		return false;
	}	
	
	// Zero value if thumbsticks are within the dead zone 
	if (state.Gamepad.sThumbLX < XINPUT_GAMEPAD_LEFT_THUMB_DEADZONE && 
		state.Gamepad.sThumbLX > -XINPUT_GAMEPAD_LEFT_THUMB_DEADZONE)
	{
		state.Gamepad.sThumbLX = 0;
	}
		
	if (state.Gamepad.sThumbLY < XINPUT_GAMEPAD_LEFT_THUMB_DEADZONE && 
		state.Gamepad.sThumbLY > -XINPUT_GAMEPAD_LEFT_THUMB_DEADZONE)
	{	
		state.Gamepad.sThumbLY = 0;
	}

	if (state.Gamepad.sThumbRX < XINPUT_GAMEPAD_RIGHT_THUMB_DEADZONE && 
		state.Gamepad.sThumbRX > -XINPUT_GAMEPAD_RIGHT_THUMB_DEADZONE)
	{
		state.Gamepad.sThumbRX = 0;
	}

	if (state.Gamepad.sThumbRY < XINPUT_GAMEPAD_RIGHT_THUMB_DEADZONE && 
		state.Gamepad.sThumbRY > -XINPUT_GAMEPAD_RIGHT_THUMB_DEADZONE)
	{
		state.Gamepad.sThumbRY = 0;
	}

	//Update button states
	for (int i = 0; i < 16; i++)
	{
		if (state.Gamepad.wButtons & (1 << i))
		{
			if (button_state[i] == BUTTON_UP)
			{
				button_state[i] = BUTTON_PRESSED;
			}
			else //if (button_state[i] == BUTTON_PRESSED)
			{
				button_state[i] = BUTTON_DOWN;
			}
		}
		else
		{
			if (button_state[i] == BUTTON_DOWN)
			{
				button_state[i] = BUTTON_RELEASED;
			}
			else //if (button_state[i] == BUTTON_RELEASED)
			{
				button_state[i] = BUTTON_UP;
			}
			
		}
	}

	return true;
}

eButtonState x360::Controller::CheckButton(eControllerButton in_button)
{
	return (button_state[in_button]);
}

float x360::Controller::CheckLeftStickX()
{
	//returns -1.0 to 1.0 (this is a percentage)
	if (state.Gamepad.sThumbLX < 0)
	{
		return (static_cast<float>(state.Gamepad.sThumbLX)/32768.0f);
	}
	else if (state.Gamepad.sThumbLX > 0)
	{
		return (static_cast<float>(state.Gamepad.sThumbLX)/32767.0f);
	}

	return (0.0f);
}

float x360::Controller::CheckLeftStickY()
{
	//returns -1.0 to 1.0 (this is a percentage)
	if (state.Gamepad.sThumbLY < 0)
	{
		return (static_cast<float>(state.Gamepad.sThumbLY)/32768.0f);
	}
	else if (state.Gamepad.sThumbLY > 0)
	{
		return (static_cast<float>(state.Gamepad.sThumbLY)/32767.0f);
	}

	return (0.0f);
}

float x360::Controller::CheckRightStickX()
{
	//returns -1.0 to 1.0 (this is a percentage)
	if (state.Gamepad.sThumbRX < 0)
	{
		return (static_cast<float>(state.Gamepad.sThumbRX)/32768.0f);
	}
	else if (state.Gamepad.sThumbRX > 0)
	{
		return (static_cast<float>(state.Gamepad.sThumbRX)/32767.0f);
	}

	return (0.0f);
}

float x360::Controller::CheckRightStickY()
{
	//returns -1.0 to 1.0 (this is a percentage)
	if (state.Gamepad.sThumbRY < 0)
	{
		return (static_cast<float>(state.Gamepad.sThumbRY)/32768.0f);
	}
	else if (state.Gamepad.sThumbRY > 0)
	{
		return (static_cast<float>(state.Gamepad.sThumbRY)/32767.0f);
	}

	return (0.0f);
}

float x360::Controller::CheckLeftTrigger()
{
	//returns 0.0 to 1.0
	return (static_cast<float>(state.Gamepad.bLeftTrigger)/255.0f);
}

float x360::Controller::CheckRightTrigger()
{
	//returns 0.0 to 1.0
	return (static_cast<float>(state.Gamepad.bRightTrigger)/255.0f);
}

int x360::Controller::getControllerNumber()
{
	return(controller_number);
}

float x360::Controller::getLeftVibration()
{
	return (static_cast<float>(vibration.wLeftMotorSpeed)/65535.0f);
}

float x360::Controller::getRightVibration()
{
	return (static_cast<float>(vibration.wRightMotorSpeed)/65535.0f);
}

bool x360::Controller::setVibration(float new_percentage_left, float new_percentage_right)
{
	if (new_percentage_left < 0.0f || new_percentage_left > 1.0f ||
		new_percentage_right < 0.0f || new_percentage_right > 1.0f)
	{
		//New percentage is out of bounds
		return false;
	}

	vibration.wLeftMotorSpeed = static_cast<WORD>(new_percentage_left * 65535);
	vibration.wRightMotorSpeed = static_cast<WORD>(new_percentage_right * 65535);
	XInputSetState( 0, &vibration );
	return true;
}
