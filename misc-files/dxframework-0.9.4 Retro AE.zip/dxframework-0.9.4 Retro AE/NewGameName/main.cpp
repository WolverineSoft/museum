#include "dxframework.h"
#include "dxf_game.h"

#include "registrar.h"

const wchar_t* kProgramName = L"NewGameName";

int WINAPI WinMain(	HINSTANCE, HINSTANCE, LPSTR, int) {	

	Registrar registrar;
	dxf::Game game;

	HRESULT hr;

	V(game.Load(kProgramName, &registrar, 1024, 768, false));
	if (SUCCEEDED(hr)) game.Run();
	
	return game.Unload();
}

