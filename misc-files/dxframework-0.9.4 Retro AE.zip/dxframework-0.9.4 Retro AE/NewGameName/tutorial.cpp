#include "tutorial.h"
#include "dxf_view.h"
#include "dxf_controller.h"
#include "dxf_game.h"

#include "registrar.h"

using namespace dxf;

#define IDC_BACK 1

void CALLBACK OnTUGUIEvent( UINT nEvent, int nControlID, CDXUTControl* pControl, void* pUserContext ) {
	Tutorial::pTutorial->OnGUIEvent(nEvent, nControlID, pControl, pUserContext);
}

Tutorial* Tutorial::pTutorial = 0;

void Tutorial::OnGUIEvent( UINT nEvent, int nControlID, CDXUTControl* pControl, void* pUserContext ) {
    switch( nControlID ) {
	case IDC_BACK:
		dxf::DXFChangeState(Registrar::kTitle);
		break;
	default:
		assert(false);
		break;
	}
}

Tutorial::Tutorial() {
	assert(!pTutorial);
	pTutorial = this;
	dialog.Init(&drm);
}

HRESULT Tutorial::Load() {
	HRESULT(hr);

	//V_RETURN(TutorialBackGround.CreateFromFile(L"Art/Instructions.png")); 
	V_RETURN(dialog.AddButton(IDC_BACK, L"Back to Title", 462, 620, 100, 25, VK_F1));

	pGUI = this;
	dialog.SetCallback(::OnTUGUIEvent);

	//const D3DSURFACE_DESC* d = DXUTGetBackBufferSurfaceDesc();

	DXFSetClear(true);

	return S_OK;
}

void Tutorial::Unload() {
	dialog.RemoveAllControls();
	drm.UnregisterDialog(&dialog);
	//TutorialBackGround.Unload();
}

void Tutorial::Update(double fTime, float fElapsedTime) {

}

void Tutorial::Render2D(double fTime, float fElapsedTime) {
	//TutorialBackGround.Render2D();
}

void Tutorial::Resize(const D3DSURFACE_DESC* d) {
}


bool Tutorial::MsgProc( HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam) {
	if (uMsg == WM_KEYDOWN && wParam == VK_ESCAPE) {
		dxf::DXFChangeState(Registrar::kTitle);
		return true;
	}
	if (drm.MsgProc( hWnd, uMsg, wParam, lParam )) return true;
	if (dialog.MsgProc( hWnd, uMsg, wParam, lParam )) return true;
	return false;
}

HRESULT Tutorial::OnResetDevice( IDirect3DDevice9* pd3dDevice, const D3DSURFACE_DESC* d) {
	HRESULT hr;
    V_RETURN(GUI::OnResetDevice(pd3dDevice, d));
	dialog.SetLocation( 0, 0 );
	dialog.SetSize( d->Width, d->Height );
	return S_OK;
}

HRESULT Tutorial::OnFrameRender(float fElapsedTime) {
	HRESULT hr;
	V_RETURN(dialog.OnRender(fElapsedTime));
	return S_OK;
}


