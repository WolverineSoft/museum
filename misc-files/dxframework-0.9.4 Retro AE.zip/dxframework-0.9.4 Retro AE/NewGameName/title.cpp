#include "title.h"
#include "dxf_view.h"
#include "dxf_controller.h"
#include "dxf_game.h"

#include "registrar.h"

using namespace dxf;
//using namespace x360;

#define IDC_QUIT 1
#define IDC_GAME 2
#define IDC_TUTORIAL 3

void CALLBACK OnGUIEvent( UINT nEvent, int nControlID, CDXUTControl* pControl, void* pUserContext ) {
	Title::pTitle->OnGUIEvent(nEvent, nControlID, pControl, pUserContext);
}

Title* Title::pTitle = 0;

void Title::OnGUIEvent( UINT nEvent, int nControlID, CDXUTControl* pControl, void* pUserContext ) {

	switch( nControlID ) {
	case IDC_GAME:
		DXFChangeState(Registrar::kOurGame);
		break;
	case IDC_TUTORIAL:
		DXFChangeState(Registrar::kTutorial);
		break;
	case IDC_QUIT:
		PostQuitMessage(0);
		break;
	default:
		assert(false);
		break;
	}
}

Title::Title() {
	assert(!pTitle);
	pTitle = this;
	dialog.Init(&drm);
}

HRESULT Title::Load() {
	HRESULT(hr);

	V_RETURN(background.CreateFromFile(L"Art/title.png"));      
	V_RETURN(dialog.AddButton(IDC_GAME, L"Play", 750, 340, 100, 25, 'Q'));V_RETURN(dialog.AddButton(IDC_TUTORIAL, L"Instructions", 750, 430, 100, 25, 'T'));
	V_RETURN(dialog.AddButton(IDC_QUIT, L"Quit!", 750, 490, 100, 25, 'Y'));
	pGUI = this;
	dialog.SetCallback(::OnGUIEvent);

	DXFSetClear(true);

	return S_OK;
}

void Title::Unload() {
	dialog.RemoveAllControls();
	drm.UnregisterDialog(&dialog);
	background.Unload();
}

void Title::Update(double fTime, float fElapsedTime) {

	/*if(!controller1.Update())
	{
		//controller not connected
	}

	//Go down one option
	if((controller1.CheckLeftStickY() < 0.0f && previous_left_stick_y >= 0.0f) || controller1.CheckButton(X360_DPAD_DOWN) == BUTTON_PRESSED || dxf::DXFCheckKeyboard(VK_DOWN) == BUTTON_PRESSED)
	{
		current_highlighted_option++;
		if (current_highlighted_option == NUM_MENU_OPTIONS)
		{
			current_highlighted_option = 0;
		}
	}	

	//Go up one option
	if((controller1.CheckLeftStickY() > 0.0f && previous_left_stick_y <= 0.0f) || controller1.CheckButton(X360_DPAD_UP) == BUTTON_PRESSED || dxf::DXFCheckKeyboard(VK_UP) == BUTTON_PRESSED)
	{
		current_highlighted_option--;
		if (current_highlighted_option < 0)
		{
			current_highlighted_option = NUM_MENU_OPTIONS - 1;
		}
	}

	previous_left_stick_y = controller1.CheckLeftStickY();*/
	
}

void Title::Render2D(double fTime, float fElapsedTime) {
	background.Render2D(D3DXVECTOR2(0, 0));

	/*for (int i = 0; i < NUM_MENU_OPTIONS; i++)
	{
		if (i != current_highlighted_option)
		{
			Globals::getGlobals()->gFont->Render2D(menu_options[i], D3DXVECTOR2(50.0f, 400.0f + 30.0f*i), WHITE);
		}
		else
		{
			Globals::getGlobals()->gFont->Render2D(menu_options[i], D3DXVECTOR2(30.0f, 400.0f + 30.0f*i), GREEN);
		}
	}*/
}

void Title::Resize(const D3DSURFACE_DESC* d) {
}


bool Title::MsgProc( HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam) {
	if (drm.MsgProc( hWnd, uMsg, wParam, lParam )) return true;
	if (dialog.MsgProc( hWnd, uMsg, wParam, lParam )) return true;

	// If you do not want escape to quit the program, uncomment this:
	if (uMsg == WM_KEYDOWN && wParam == VK_ESCAPE) {
		// Do something useful with escape
		// Let the engine know we've processed the escape message
		return true;
	}		

	return false;
}

HRESULT Title::OnResetDevice( IDirect3DDevice9* pd3dDevice, const D3DSURFACE_DESC* d) {
	HRESULT hr;
    V_RETURN(GUI::OnResetDevice(pd3dDevice, d));
	dialog.SetLocation( 0, 0 );
	dialog.SetSize( d->Width, d->Height );
	return S_OK;
}

HRESULT Title::OnFrameRender(float fElapsedTime) {
	HRESULT hr;
	V_RETURN(dialog.OnRender(fElapsedTime));
	return S_OK;
}


