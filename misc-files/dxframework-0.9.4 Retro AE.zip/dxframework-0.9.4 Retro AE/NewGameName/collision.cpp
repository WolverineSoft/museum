#include "collision.h"

//Returns true if a (potentially) moving rectangle collides with a non-moving line
bool lineIntersectWithRectangle(D3DXVECTOR2 linePointA, D3DXVECTOR2 linePointB, D3DXVECTOR2 rectStartPos, D3DXVECTOR2 rectNewPos, unsigned int rectWidth, unsigned int rectHeight) {
	//Variables
	double yO1, yO2, vX1, vX2, vY1, vY2, xO1, xO2, yF1, yF2, xF1, xF2;
	xO1 = linePointA.x;
	xF1 = linePointB.x;
	yO1 = linePointA.y;
	yF1 = linePointB.y;
	vX1 = xF1 - xO1;
	vY1 = yF1 - yO1;
	

	unsigned int halfWidth, halfHeight;
	halfWidth = rectWidth/2;
	halfHeight = rectHeight/2;

	xO2 = rectStartPos.x + halfWidth;
	xF2 = rectNewPos.x + halfWidth;
	yO2 = rectStartPos.y + halfHeight;
	yF2 = rectNewPos.y + halfHeight;
	vX2 = xF2 - xO2;
	vY2 = yF2 - yO2;
	
	//Undefined slope
	if (vX1 == 0)
	{
		swap(vX1, vY1);
		swap(xO1, yO1);
		swap(xF1, yF1);
		swap(vX2, vY2);
		swap(xO2, yO2);
		swap(xF2, yF2);
	}

	//Check if lines are parallel, and not the same line
	if ((vY1/vX1 - vY2/vX2) != 0) {
		//Get X coord of intersection
		double xIntersect = (yO2 - yO1 + (vY1/vX1)*xO1 - (vY2/vX2)*xO2)/(vY1/vX1 - vY2/vX2);

		//Get Y coord of intersection
		double yIntersect = yO2 + vY2/vX2*(xIntersect - xO2);

		//Check if X and Y were passed through on this update
		if ((xIntersect >= xO2 && xIntersect <= xF2 || xIntersect <= xO2 && xIntersect >= xF2)
			&& (xIntersect >= xO1 && xIntersect <= xF1 || xIntersect <= xO1 && xIntersect >= xF1)) {
			return true;
		}
	}
	return false;
}

// Checks for rectangle intersection with circle
bool rectIntersectWithCircle(D3DXVECTOR2 rectNewPos, D3DXVECTOR2 circleCenter, unsigned int radius) {
	double distance = sqrt((rectNewPos.x - circleCenter.x) * (rectNewPos.x - circleCenter.x)
						 + (rectNewPos.y - circleCenter.y) * (rectNewPos.y - circleCenter.y));
	if (distance <= radius) {
		return true;
	}
	return false;
}
