#pragma once

#include "dxframework.h"
#include "dxf.h"
//#include "controller.h"

//const int NUM_MENU_OPTIONS = 5;

class Title : public dxf::GameState, public dxf::GUI {
public:
	Title();

	virtual HRESULT Load();
	virtual void Unload();

	virtual void Update(double fTime, float fElapsedTime);
	virtual void RenderPre2D(double fTime, float fElapsedTime) {};
	virtual void Render3D(double fTime, float fElapsedTime) {};
	virtual void Render2D(double fTime, float fElapsedTime);
	virtual void Resize(const D3DSURFACE_DESC* pBackBufferSurfaceDesc);
	virtual bool MsgProc( HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam);

	virtual HRESULT OnResetDevice( IDirect3DDevice9* pd3dDevice, const D3DSURFACE_DESC* pBackBufferSurfaceDesc);
	virtual HRESULT OnFrameRender(float fElapsedTime);
	virtual void OnGUIEvent( UINT nEvent, int nControlID, CDXUTControl* pControl, void* pUserContext );

	static Title* pTitle;

protected:
	CDXUTDialog dialog;
	dxf::Sprite background;

	/*int current_highlighted_option;
	std::wstring menu_options[NUM_MENU_OPTIONS];

	x360::Controller controller1;
	float previous_left_stick_y;*/
};
