#include "highscoretable.h"
#include <fstream>
#include <sstream>
#include <string>
#include <algorithm>

using std::ifstream;
using std::ofstream;
using std::istringstream;
using std::endl;
using std::string;
using std::map;
using std::vector;

bool operator<(const HighScore & h1, const HighScore & h2)
{
	return h1.entry.second < h2.entry.second;
}

bool greater_than(const HighScore & h1, const HighScore & h2)
{
	return h1.entry.second > h2.entry.second;
}

name_and_score_t HighScoreTable::parse_name_and_score(const std::string & str) const
{
	name_and_score_t ret;
	string::size_type end_name = str.find(',');

	ret.first = str.substr(0, end_name);
	
	istringstream conv(str.substr(end_name + 1));
	conv >> ret.second;

	return ret;
}

HighScoreTable::HighScoreTable(const std::string & filename)
{
	ifstream file(filename.c_str());

	if(!file)
	{
		file.close();
		ofstream ofile(filename.c_str());

		for(unsigned int i = 0; i < NUM_SCORES; i++)
		{
			ofile << "_,0,0" << endl;
		}
		ofile.close();
		file.open(filename.c_str());
	}
		scores.reserve(NUM_SCORES);

		/* XXX: no error checking on the high score file for now */
		for(unsigned int i = 0; i < NUM_SCORES && !file.eof(); ++i)
		{
			string line;
			HighScore score;

			getline(file, line);

			string::size_type end_score = line.rfind(',');
			if(end_score == string::npos)
			{
				continue;
			}

			score.entry = parse_name_and_score(line.substr(0,
								end_score));

			istringstream conv(line.substr(end_score + 1));
			conv >> score.level;

			scores.push_back(score);
		}

		while(!file.eof() && !file.fail())
		{
			string line;
			
			getline(file, line);
			string::size_type end_high = line.find(',');

			if(end_high == string::npos)
			{
				continue;
			}

			highs[line.substr(0, end_high)] =
				parse_name_and_score(line.substr(end_high + 1));
		}

		std::sort(scores.begin(), scores.end(), greater_than);
}

void HighScoreTable::save_to_file(const std::string & filename)
{
	ofstream file(filename.c_str());


	for(int i = 0; i < scores.size(); i++)
	{
		file << scores[i].entry.first << ',' << scores[i].entry.second
		     << ',' << scores[i].level << endl;
	}

	map<string,name_and_score_t>::const_iterator j;
	for(j = highs.begin(); j != highs.end(); ++j)
	{
		file << j->first << ',' << j->second.first << ','
		     << j->second.second << endl;
	}
}

bool HighScoreTable::is_high_score(unsigned long score) const
{
	return score >= scores.rbegin()->entry.second;
}

void HighScoreTable::add_score(const string & name, unsigned long score,
			       unsigned long level)
{
	HighScore hs;
	hs.entry.first = name;
	hs.entry.second = score;
	hs.level = level;

	vector<HighScore>::iterator i;

	for(i = scores.begin(); i != scores.end(); i++)
	{
		if(score > i->entry.second)
		{
			break;
		}
	}

	/* Don't put in unqualified scores */
	if(i != scores.end())
	{
		scores.insert(i, hs);
		scores.pop_back();
	}
}

bool HighScoreTable::is_all_time_high(const string & high_name,
				      unsigned long high) const
{
	map<string, name_and_score_t>::const_iterator i = highs.find(high_name);
	return (i == highs.end() || i->second.second
			<= high);
}

void HighScoreTable::add_all_time_high(const string & high_name,
				       const string & player_name,
		       unsigned long high)
{
	highs[high_name].first = player_name;
	highs[high_name].second = high;
}

name_and_score_t HighScoreTable::get_high(const string & name) const
{
	map<string, name_and_score_t>::const_iterator i = highs.find(name);
	if(i == highs.end())
	{
		return std::make_pair(string("_"),0);
	}

	return i->second;
}

const std::vector<HighScore> &
HighScoreTable::get_scores() const
{
	return scores;
}
