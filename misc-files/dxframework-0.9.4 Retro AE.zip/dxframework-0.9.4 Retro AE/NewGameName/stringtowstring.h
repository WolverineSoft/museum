#ifndef __STRINGTOWSTRING_H
#define __STRINGTOWSTRING_H

#include <string>

std::wstring to_wstring(const std::string & str);
std::string to_string(const std::wstring & wstr);

#endif /* __STRINGTOWSTRING_H */
