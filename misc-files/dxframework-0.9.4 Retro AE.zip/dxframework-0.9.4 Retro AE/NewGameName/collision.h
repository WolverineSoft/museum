#ifndef COLLISION_H
#define COLLISION_H

#include <d3dx9math.h>

//Returns true if a (potentially) moving rectangle collides with a non-moving line
bool lineIntersectWithRectangle(D3DXVECTOR2 linePointA, D3DXVECTOR2 linePointB, D3DXVECTOR2 rectStartPos, D3DXVECTOR2 rectNewPos, unsigned int rectWidth, unsigned int rectHeight);

// Checks for rectangle intersection with circle
bool rectIntersectWithCircle(D3DXVECTOR2 rectNewPos, D3DXVECTOR2 circleCenter, unsigned int radius);

#endif
