#pragma once

#include "dxframework.h"
#include "dxf_game.h"

//#include "title.h"
#include "ourGame.h"
//#include "tutorial.h"

class Registrar : public dxf::RegistrarInterface {
public:
	virtual void RegisterStates();
	virtual void RegisterCommands();

	//static const wchar_t* kTitle;
	static const wchar_t* kOurGame;
	//static const wchar_t* kTutorial;

private:
	//Title title;
	OurGame ourGame;
	//Tutorial tutorial;
};
