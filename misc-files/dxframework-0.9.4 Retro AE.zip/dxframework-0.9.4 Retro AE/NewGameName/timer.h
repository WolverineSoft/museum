#pragma once

class Timer
{
public:
	Timer() {}

	void Initialize(const float &in_increment)
	{
		m_fIncrement = in_increment;
		m_fElapsed = 0.0f;
	}


	void SetIncrement(const float &in_increment)
	{
		m_fIncrement = in_increment;
	}

	void Update(const float &in_elapsed)
	{
		m_fElapsed += in_elapsed;
	}

	void Reset()
	{
		m_fElapsed = 0.0f;
	}

	bool CheckTimePassed()
	{
		if(m_fElapsed > m_fIncrement)
		{
			m_fElapsed -= m_fIncrement;
			return true;
		}
		else
		{
			return false;
		}
	}

private:
	float m_fElapsed;
	float m_fIncrement;

};