#include "registrar.h"
#include "dxf_console.h"
#include "dxf_tools.h"

using namespace dxf;

//const wchar_t* Registrar::kTitle = L"Title";
const wchar_t* Registrar::kOurGame = L"OurGame";
//const wchar_t* Registrar::kTutorial = L"Tutorial";

void add(std::vector<std::wstring>& argv) {
	if (argv.size() < 3) {
		Console::output << L"I need at least 2 numbers to add anything." << std::endl;
	}

	int accumulator = 0;
	for (std::vector<std::wstring>::iterator iter = ++(argv.begin()); iter != argv.end(); ++iter) {
		accumulator += dxf::toint(*iter);
	}
	Console::output << L"Result is " << accumulator << std::endl;
}

void Registrar::RegisterStates() {
	//DXUTToggleFullScreen();

//	DXFRegisterState(kTitle, &title);
	DXFRegisterState(kOurGame, &ourGame);
//	DXFRegisterState(kTutorial, &tutorial);
}

void Registrar::RegisterCommands() {
	//DXFRegisterCommand(L"add", &add);	
}
