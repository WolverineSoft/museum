/*	DXFramework Copyright (c) 2005, Jonathan Voigt, University of Michigan.
	See http://dxframework.sourceforge.net/ for a list of contributors.
	All rights reserved.

	Redistribution and use in source and binary forms, with or without modification, 
	are permitted provided that the following conditions are met:

		* Redistributions of source code must retain the above copyright notice, 
		this list of conditions and the following disclaimer.

		* Redistributions in binary form must reproduce the above copyright notice, 
		this list of conditions and the following disclaimer in the documentation 
		and/or other materials provided with the distribution.

		* Neither the name of the DXFramework project nor the names of its 
		contributors may be used to endorse or promote products derived from this 
		software without specific prior written permission.

	THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND 
	ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED 
	WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE 
	DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR 
	ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES 
	(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; 
	LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON 
	ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT 
	(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS 
	SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/

#include "ourGame.h"
#include "registrar.h"
//#include "highscoretable.h"

using namespace dxf;


//Statics
//OurGame* OurGame::pOurGame = NULL;

D3DXVECTOR2 pause_render_point;

OurGame::OurGame() {
	/*assert(!pOurGame);	// singleton
	pOurGame = this;*/
}

HRESULT OurGame::Load() {
	//HRESULT hr;
	
	//Load font
	//V_RETURN(font.Load(L"Helvitica", 40, FW_NORMAL));

	//Load all images
	//V_RETURN(background.CreateFromFile(L"Art/Background.png"));
	//V_RETURN(pause_sprite.CreateFromFile(L"Art/Paused.png"));
	//V_RETURN(game_song.Load(L"Sounds/Luminaria2.mp3"));
	//game_song.Play();

	DXUTSetCursorSettings(true, true);

	//Initialize game
	paused = false;
	//pause_render_point = D3DXVECTOR2((1024 - float(pause_sprite.GetWidth()))/2, (768 - float(pause_sprite.GetHeight()))/2);

	return S_OK;
}

void OurGame::Unload()
{
	//game_song.Unload();
	//pause_sprite.Unload();
	//background.Unload();
	//font.Unload();
}

void OurGame::Update(double fTime, float fElapsedTime)
{
	if (paused)
	{
		if (DXFCheckKeyboard('P') == BUTTON_PRESSED)
		{
            paused = false;
		}
		/*if (DXFCheckKeyboard('U') == BUTTON_PRESSED)
		{
            long volume;
			game_song.GetVolume(&volume);
			game_song.SetVolume(volume + 100);
		}
		if (DXFCheckKeyboard('J') == BUTTON_PRESSED)
		{
            long volume;
			game_song.GetVolume(&volume);
			game_song.SetVolume(volume - 100);
		}
		if (DXFCheckKeyboard('V') == BUTTON_PRESSED)
		{
            long balance;
			game_song.GetBalance(&balance);
			game_song.SetBalance(balance - 100);
		}
		if (DXFCheckKeyboard('B') == BUTTON_PRESSED)
		{
            long balance;
			game_song.GetBalance(&balance);
			game_song.SetBalance(balance + 100);
		}
		if (DXFCheckKeyboard('W') == BUTTON_PRESSED)
		{
			D3DXCOLOR new_color(pause_sprite.GetColor());
			float r = new_color.r + float(0.01);
			float g = new_color.g + float(0.01);
			float b = new_color.b + float(0.01);
			float a = new_color.a + float(0.01);
			new_color = D3DXCOLOR(r,g,b,a);
			pause_sprite.SetColor(new_color);
			double rate;
			game_song.GetRate(&rate);
			game_song.SetRate(rate + 0.1);
		}
		if (DXFCheckKeyboard('S') == BUTTON_PRESSED)
		{
			D3DXCOLOR new_color(pause_sprite.GetColor());
			float r = new_color.r - float(0.01);
			float g = new_color.g - float(0.01);
			float b = new_color.b - float(0.01);
			float a = new_color.a - float(0.01);
			new_color = D3DXCOLOR(r,g,b,a);
			pause_sprite.SetColor(new_color);
			double rate;
			game_song.GetRate(&rate);
			game_song.SetRate(rate - 0.1);
		}*/
	}
	else
	{
		if (DXFCheckKeyboard('P') == BUTTON_PRESSED)
		{
            paused = true;
		}
		/*if (DXFCheckMouse(MBUTTON_LEFT) == BUTTON_PRESSED)
		{
			dxf::DXFChangeState(Registrar::kTitle);
		}*/
		/*if (gameover)
		{
			//Update highscore list
			HighScoreTable hst(SCORE_FILE);
			if (hst.is_high_score(score)) {
				DXFChangeState(Registrar::kHighScoreEntry);
			}
		}*/
	}
}

void OurGame::Render2D(double fTime, float fElapsedTime) {
	//Draw everything (order matters)
	//background.Render2D();
	//D3DXCOLOR is RGBA
	//font.Render2D(L"I am a font.", D3DXVECTOR2(57, 442), D3DXCOLOR(0,0,255,80));
	if (paused)
	{
		//pause_sprite.Render2D(pause_render_point);
	}
}

bool OurGame::MsgProc( HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam) {
	if (uMsg == WM_KEYDOWN && wParam == VK_ESCAPE) {
		//dxf::DXFChangeState(Registrar::kTitle);
		exit(0);
		//return true;	// Return true here to let the engine know we've processed that message.
	}		
	return false;
}
