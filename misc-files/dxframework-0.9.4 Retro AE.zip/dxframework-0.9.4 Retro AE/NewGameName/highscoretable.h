#ifndef HIGHSCORETABLE_H
#define HIGHSCORETABLE_H

#include <string>
#include <vector>
#include <map>

/**
 * Type correlating player names to scores.
 */
typedef std::pair<std::string, unsigned long> name_and_score_t;

struct HighScore
{
	name_and_score_t entry;
	unsigned long level;
};

bool operator<(const HighScore & h1, const HighScore & h2);

class HighScoreTable
{
	std::vector<HighScore> scores;
	std::map<std::string, name_and_score_t> highs;
	
	/**
	 * Parses a name and score string, e.g. "Jesus H. Christ, 9999".
	 */
	name_and_score_t parse_name_and_score(const std::string & str) const;
public:
	/**
	 * Number of scores in the table.
	 */
	static const unsigned int NUM_SCORES = 10;

#if 0
	/**
	 * Create a new high score table.
	 */
	HighScoreTable() {}
#endif

	/**
	 * Create a high score table from the file filename, or an empty table
	 * if filename is the incorrect format or not found.
	 */
	HighScoreTable(const std::string & filename);

	/**
	 * Save this high score table to the file filename, overwriting it if it
	 * already exists.
	 */
	void save_to_file(const std::string & filename);

	/**
	 * Return true if score qualifies for entry into this table; false
	 * otherwise. I recommend calling this before asking the player to enter
	 * his name.
	 */
	bool is_high_score(unsigned long score) const;

	void add_score(const std::string & name, unsigned long score,
		       unsigned long level);

	/**
	 * Return true if high is higher than the current high for high_name.
	 * I do not smoke pot.
	 */
	bool is_all_time_high(const std::string & high_name,
			      unsigned long high) const;

	/**
	 * If high is higher than the current high for high_name, credits player
	 * with high as the high for high_name. Else, does nothing.
	 */
	void add_all_time_high(const std::string & high_name,
			       const std::string & player_name,
			       unsigned long high);

	/**
	 * Returns the all-time high for the high with name name.
	 */
	name_and_score_t get_high(const std::string & name) const;

	/**
	 * Return the scores in the table, highest first.
	 */
	const std::vector<HighScore> & get_scores() const;
};

#endif /* HIGHSCORETABLE_H */
