#include "HighScores.h"
#include "dxf_view.h"
#include "dxf_controller.h"
#include "dxf_game.h"

#include "registrar.h"

#include "highscoretable.h"
#include <sstream>
#include <iomanip>

using namespace dxf;
using std::vector;
using std::string;
using std::ostringstream;

#define IDC_QUIT 1

	static const int MARGIN_WIDTH = 120;
	static const int NAME_WIDTH = 338;
	static const int LEVEL_WIDTH = 120;
	static const int ROW_HEIGHT = 40;
	const char * SCORE_FILE  = "../NewGameNameScores.hst";
void CALLBACK OnHSGUIEvent( UINT nEvent, int nControlID, CDXUTControl* pControl, void* pUserContext ) {
	HighScores::pHighScores->OnGUIEvent(nEvent, nControlID, pControl, pUserContext);
}

HighScores* HighScores::pHighScores = 0;

string pad_to_n_digits(int x, int n)
{
	ostringstream conv;

	conv << std::setfill('0') << std::right << std::setw(n) << x;
	return conv.str();
}

string lookup_high(const HighScoreTable & hst, string high_name)
{
	ostringstream conv;
	name_and_score_t entry = hst.get_high(high_name);

	conv << entry.first << "      " << pad_to_n_digits(entry.second,4);

	return conv.str();
}

void HighScores::OnGUIEvent( UINT nEvent, int nControlID, CDXUTControl* pControl, void* pUserContext ) {
    switch( nControlID ) {
	case IDC_QUIT:
		DXFChangeState(Registrar::kTitle);
		break;
	default:
		assert(false);
		break;
	}
}

HighScores::HighScores() {
	assert(!pHighScores);
	pHighScores = this;
	dialog.Init(&drm);
}

HRESULT HighScores::Load() {
	HRESULT(hr);

	V_RETURN(font.Load(L"Helvitica", 36, FW_NORMAL));

	//V_RETURN(background.CreateFromFile(L"Art/HighScoresBackground.png"));      
	V_RETURN(dialog.AddButton(IDC_QUIT, L"Back to Title", 460, 640, 100, 25, 'Q'));

	pGUI = this;
	dialog.SetCallback(::OnHSGUIEvent);

	const D3DSURFACE_DESC* d = DXUTGetBackBufferSurfaceDesc();

	DXFSetClear(true);
	return S_OK;
}

void HighScores::Unload() {
	dialog.RemoveAllControls();
	drm.UnregisterDialog(&dialog);
	//background.Unload();
}

void HighScores::Update(double fTime, float fElapsedTime) {
}

void HighScores::Render2D(double fTime, float fElapsedTime) {
	//background.Render2D(D3DXVECTOR2(0, 0));
	font.Render2D(L"High Scores", D3DXVECTOR2(418,ROW_HEIGHT));

	//Heading
	font.Render2D(L"Name", D3DXVECTOR2(MARGIN_WIDTH, 2*ROW_HEIGHT));
	font.Render2D(L"Score", D3DXVECTOR2(MARGIN_WIDTH + NAME_WIDTH, 2*ROW_HEIGHT));
	font.Render2D(L"Level", D3DXVECTOR2(1024 - MARGIN_WIDTH - LEVEL_WIDTH, 2*ROW_HEIGHT));

	HighScoreTable hst(SCORE_FILE);
	const vector<HighScore> & scores = hst.get_scores();
	vector<HighScore>::size_type i;
	//Actual scores...I guess they don't even need numbering
	for(i = 0; i < scores.size(); i++)
	{
		FLOAT ypos = (3 + i) * ROW_HEIGHT;
		font.Render2D(to_wstring(scores[i].entry.first), D3DXVECTOR2(MARGIN_WIDTH, ypos));
		font.Render2D(to_wstring(pad_to_n_digits(scores[i].entry.second,7)), D3DXVECTOR2(MARGIN_WIDTH + NAME_WIDTH - 20, ypos));
		font.Render2D(to_wstring(pad_to_n_digits(scores[i].level,3)), D3DXVECTOR2(1024-MARGIN_WIDTH-LEVEL_WIDTH, ypos));
	}
	//SIZE sz;
	//wstring temp(to_wstring(lookup_high(hst, "Best Streak")));
	//font.Render2D(L"Best Streak:", D3DXVECTOR2(MARGIN_WIDTH, (3 + i) * ROW_HEIGHT));
	//font.GetTextExtent(L"Best Streak:", sz);
	//font.Render2D(temp, D3DXVECTOR2(MARGIN_WIDTH + NAME_WIDTH - 52, (3 + i) * ROW_HEIGHT));

	//temp = to_wstring(lookup_high(hst, "Biggest Dream"));
	//font.Render2D(L"Biggest Dream:", D3DXVECTOR2(MARGIN_WIDTH, (4 + i) * ROW_HEIGHT));
	//font.GetTextExtent(L"Biggest Dream:",sz);
	//font.Render2D(temp, D3DXVECTOR2(MARGIN_WIDTH + NAME_WIDTH - 52, (4 + i) * ROW_HEIGHT));
}

void HighScores::Resize(const D3DSURFACE_DESC* d) {
}


bool HighScores::MsgProc( HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam) {
	if (drm.MsgProc( hWnd, uMsg, wParam, lParam )) return true;
	if (dialog.MsgProc( hWnd, uMsg, wParam, lParam )) return true;

	// If you do not want escape to quit the program, uncomment this:
	if (uMsg == WM_KEYDOWN && wParam == VK_ESCAPE) {
		// Do something useful with escape
		// Let the engine know we've processed the escape message
		return true;
	}		

	return false;
}

HRESULT HighScores::OnResetDevice( IDirect3DDevice9* pd3dDevice, const D3DSURFACE_DESC* d) {
	HRESULT hr;
    V_RETURN(GUI::OnResetDevice(pd3dDevice, d));
	dialog.SetLocation( 0, 0 );
	dialog.SetSize( d->Width, d->Height );
	return S_OK;
}

HRESULT HighScores::OnFrameRender(float fElapsedTime) {
	HRESULT hr;
	V_RETURN(dialog.OnRender(fElapsedTime));
	return S_OK;
}


